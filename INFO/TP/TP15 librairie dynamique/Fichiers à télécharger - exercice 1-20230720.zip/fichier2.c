int plusgrand(int arg1, int arg2)
{
  if (arg1 < arg2)
    return arg2;
  else
    return arg1;
}
