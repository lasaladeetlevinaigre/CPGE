module Wgraph  =

  struct 
    type 'w t =
      {
        (* compléter *)
      };;

    (* écrire ci-dessous toutes les primitives associées à la structure de données *)
    
    (* constructeur *)
    
    (* accesseurs *)
    

    (* transformateurs *)
   

  end
;;





  
