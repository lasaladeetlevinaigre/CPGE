void print_tab(int *t, int n, int max);
int *generate_random_array(int n, int a, int b);
int quicksort(int *tab, int n);
void insertion_sort(int *tab, int n);
