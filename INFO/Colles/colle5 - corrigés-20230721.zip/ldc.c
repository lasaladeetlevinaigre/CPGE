#include<stdio.h>
#include<stdlib.h>
#include<assert.h>
#include<time.h>


struct cell
{
  
  float val;
  struct cell* addr_p;
  struct cell* addr_n;
 
};
typedef struct cell cell;


struct ldc
{
  cell* frst;
  unsigned int lg; // PROF: pourquoi lg?? longueur? essayez de ne pas trop mélanger anglais et français...
};
typedef struct ldc ldc;


ldc * ldc_create()
{
  ldc*new=malloc(sizeof(ldc));
  new->frst=NULL;
  new->lg=0;
  return new;
}
  
void ldc_push(ldc* list, float x)
{
  cell* new=malloc(sizeof(cell));
  new->val=x;
  new->addr_n=list->frst;
  new->addr_p=NULL;
  if(list->lg!=0)
    list->frst->addr_p=new;
  list->frst=new;
  list->lg=list->lg+1;
}

void ldc_print(ldc* list)
{
  printf("Longueur de la chaine affichee : %d\n", list->lg);
  cell *tete=list->frst;
  for(int i=0; i<list->lg; i++)
    {
      printf("Val 0%d : %f\n", i,  tete->val);
      //float xend;
      //float xew;
      //if(i!=0) xew=tete->addr_p->val; else  xew=0000000100000000;
      //if(i==list->lg-1) xend=111111111101111111111.;else  xend=tete->addr_n->val;
      //printf("Val precedente :%f\n Val suiv : %f\n\n", xew, xend );
      tete=tete->addr_n;
    };
}


void ldc_free(ldc* list)
{
  cell *tete=list->frst;
  for(int i=0; i<list->lg; i++) // un peu dangereux... si par malchance lg n'est pas bon, vous pouvez vous retrouver avec des pointeurs nulls...
    {
      cell *tmp=tete->addr_n; // PROF: ne déclarez pas de variable en plein milieu d'une boucle. Déclarez tmp au début, en l'initialisant à NULL
      free(tete);
      tete=tmp;
    };
  free(list);
}

float ldc_pop(ldc*list)
{
  cell *tete=list->frst;
  float x=tete->val;
  list->frst=tete->addr_n;
  tete->addr_n->addr_p=NULL;
  (list->lg)--;
  free(tete);
  return x;
  
}

cell* ldc_travel(ldc* list, int n)
{
  assert(n>=0);
  assert(n<=list->lg);
  cell *tete=list->frst;
  for(int i=0; i<n; i++) // PROF: même remarque, un peu dangereux
    {
      tete=tete->addr_n;
    };
  return tete;
}
void ldc_insert_ith(ldc *list, float x, int n)
{
  if(n==0)
    {
      ldc_push(list, x);
    }else // PROF: attention à l'indentation
    {   
      cell *pre_ith=ldc_travel(list, n-1); // PROF: même remarque: déclarez ces variables locales en début de fonction, et initialisez les à NULL
      cell *new=malloc(sizeof(cell));

      // PROF: top le rebranchement, vous avez dessiné :-)
      new->val=x;
      new->addr_p=pre_ith;
      new->addr_n=pre_ith->addr_n;
      pre_ith->addr_n->addr_p=new;
      pre_ith->addr_n=new;
      list->lg ++;
    }; // PROF: point virgule inutile!
}

void ldc_delete_ith(ldc *list, int n)
{
  if(n==0)
    {
      ldc_pop(list);
    }else
    {   
      cell *ith=ldc_travel(list, n);
      cell*pre=ith->addr_p;
      cell*nxt=ith->addr_n;
      pre->addr_n=nxt;
      nxt->addr_p=pre;
      list->lg--;
      
    };
}

// PROF: top, vous avez compris!
void ldc_reverse(ldc *list)
{
  cell*tete=list->frst;
  tete->addr_p=tete->addr_n;
  tete->addr_n=NULL;
  tete=tete->addr_p;
  for(int i=1; i<list->lg-1; i++)
    {
      cell*tmp=tete->addr_n;
      tete->addr_n=tete->addr_p;
      tete->addr_p=tmp;
      tete=tete->addr_p;
    };
  tete->addr_n=tete->addr_p;
  tete->addr_p=NULL;
  list->frst=tete;
}

// PROF:  ca doit marcher mais difficile à lire!
// En tout cas, vous avez bien réfléchi et testé!!
void ldc_swap(ldc *list, cell*c1, cell*c2)
{
  // ATTENTION 2 c1 et c2 : maillons_successifs, c1 en 1er
  assert(c1!=NULL);
  assert(c2!=NULL);
  void aux(cell*c1, cell*c2) // PROF: chaud en C, pas de fonction imbriquée dans une fonction... totalement hors programme et pas du tout idiomatique...
  {
    cell*tmp=c1->addr_p;
    c1->addr_n=c2->addr_n;
    c1->addr_p=c2;
    c2->addr_n=c1;
    c2->addr_p=tmp;
  };
    
  //printf("Avant : %f  et   %f\n", c1->val, c2->val);
  if(c1->addr_p==NULL)
    {
      list->frst=c2;
      if(c2->addr_n!=NULL)c2->addr_n->addr_p=c1;
      aux(c1, c2);
    }
  else
    {
      if(c2->addr_n!=NULL)c2->addr_n->addr_p=c1;
      if(c1->addr_p!=NULL)c1->addr_p->addr_n=c2;
      aux(c1, c2);
    }
      
  /*
      c2->addr_n->addr_p=c1;
  //c1->addr_p->addr_n=c2;
  */

  //printf("Apres : %f  et %f\n\n", c1->addr_p->val, c2->addr_n->val);
}


void ldc_tri_insertion(ldc *list)
{
  cell*point;
  for(int i=1;i<list->lg;i++)
    {
     point=ldc_travel(list, i);
     //printf("Val point : %f\n", point->val);

     // PROF: je pense qu'il y a une erreur ici sur l'opérateur de déréférencement
     // Il semble s'appliquer au champ val qui est un entier et non une adresse
     // En fait, ce sont juste les valeurs que vous devez comparez, sans dérénférencement
     // DU coup, c'est de la d'où vient l'erreur de compilation
     while(*(point->val)<*(point->addr_p->val))
       {
	 //printf("\tVal du pt : %f\n\n____________________", point->val);
	 ldc_swap(list, point->addr_p, point);
	 if(point->addr_p==NULL) break;
	 
       };
    };
 
}


int main()
{
  srand(time(0)); // PROF: time(NULL), la fonction time attend un pointeur
  
  ldc *jojo=ldc_create();
  for(int i=0 ; i<11;i++)ldc_push(jojo, i); // PROF: allez à la ligne, ca sera apprécié niveau lisibilité
  ldc_print(jojo);
  printf("Tete enlevee : %f\nNouvelle liste :\n", ldc_pop(jojo));
  ldc_print(jojo);
  

  printf("Test : fonction insert  :\n");
  ldc_insert_ith(jojo, 999, 0);
  ldc_print(jojo);
  

  printf("Test fonction delete :\n");
  ldc_delete_ith(jojo, 0);
  ldc_print(jojo);
  
  //______________________Deux_______________

  printf("\nTest no 2: fonction insert  :\n");
  ldc_insert_ith(jojo, 999, 5);
  ldc_print(jojo);
  

  printf("Test no 2: fonction delete :\n");
  ldc_delete_ith(jojo, 5);
  ldc_print(jojo);

  
  printf("\nTest fonction inverse :\n");
  ldc_reverse(jojo);
  ldc_print(jojo);

  //__________Test tri_insertion______________

  ldc* jaja=ldc_create();
  for(int i=0; i<1000;i++)ldc_push(jaja, rand()%100);
  printf("Liste non triée :\n");
  ldc_print(jaja);
  printf("Liste triée\n");
  ldc_tri_insertion(jaja);
  ldc_print(jaja);

  
  

    






  free(jaja);
  free(jojo);

  // PROF: erreur ici, la fonction main retourne toujours un entier: 0 si tout est OK, 1 sinon
}
