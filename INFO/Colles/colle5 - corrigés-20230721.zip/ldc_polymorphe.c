#include<stdio.h>
#include<stdlib.h>
#include<assert.h>
#include<time.h>

#define elem_t float


struct cell
{
  
  void* val;
  struct cell* addr_p;
  struct cell* addr_n;
 
};
typedef struct cell cell;


struct ldc
{
  cell* frst;
  unsigned int lg;
};
typedef struct ldc ldc;


ldc * ldc_create()
{
  ldc*new=malloc(sizeof(ldc));
  new->frst=NULL;
  new->lg=0;
  return new;
}
  
void ldc_push(ldc* list, void* x)
{
  cell* new=malloc(sizeof(cell));
  new->val=x;
  new->addr_n=list->frst;
  new->addr_p=NULL;
  if(list->lg!=0) list->frst->addr_p=new;
  list->frst=new;
  list->lg=list->lg+1;
}

void ldc_print(ldc* list)
{
  printf("Longueur de la chaine affichee : %d\n", list->lg);
  cell *tete=list->frst;
  for(int i=0; i<list->lg; i++)
    {
      printf("Val 0%d : %f\n", i,  *((elem_t*)(tete->val)));
      //float xend;
      //float xew;
      //if(i!=0) xew=tete->addr_p->val; else  xew=0000000100000000;
      //if(i==list->lg-1) xend=111111111101111111111.;else  xend=tete->addr_n->val;
      //printf("Val precedente :%f\n Val suiv : %f\n\n", xew, xend );
      tete=tete->addr_n;
    };
}


void ldc_free(ldc* list)
{
  cell *tete=list->frst;
  for(int i=0; i<list->lg; i++)
    {
      cell *tmp=tete->addr_n;
      free(tete->val);
      free(tete);
      tete=tmp;
    };
  free(list);
}

void* ldc_pop(ldc*list)
{
  cell *tete=list->frst;
  void * x=tete->val;
  list->frst=tete->addr_n;
  tete->addr_n->addr_p=NULL;
  (list->lg)--;
  free(tete->val);
  free(tete);
  return x;
  
}

cell* ldc_travel(ldc* list, int n)
{
  assert(n>=0);
  assert(n<=list->lg);
  cell *tete=list->frst;
  for(int i=0; i<n; i++)
    {
      tete=tete->addr_n;
    };
  return tete;
}



void ldc_insert_ith(ldc *list, void *x, int n)
{
  if(n==0)
    {
      ldc_push(list, x);
    }else
    {   
      cell *pre_ith=ldc_travel(list, n-1);
      cell *new=malloc(sizeof(cell));
      new->val=x;
      new->addr_p=pre_ith;
      new->addr_n=pre_ith->addr_n;
      pre_ith->addr_n->addr_p=new;
      pre_ith->addr_n=new;
      list->lg ++;
    };
}

void ldc_delete_ith(ldc *list, int n)
{
  if(n==0)
    {
      ldc_pop(list);
    }else
    {   
      cell *ith=ldc_travel(list, n);
      cell*pre=ith->addr_p;
      cell*nxt=ith->addr_n;
      pre->addr_n=nxt;
      nxt->addr_p=pre;
      list->lg--;
      free(ith->val);
      free(ith);
      
    };
}

void ldc_reverse(ldc *list)
{
  cell*tete=list->frst;
  tete->addr_p=tete->addr_n;
  tete->addr_n=NULL;
  tete=tete->addr_p;
  for(int i=1; i<list->lg-1; i++)
    {
      cell*tmp=tete->addr_n;
      tete->addr_n=tete->addr_p;
      tete->addr_p=tmp;
      tete=tete->addr_p;
    };
  tete->addr_n=tete->addr_p;
  tete->addr_p=NULL;
  list->frst=tete;
}

void ldc_swap(ldc *list, cell*c1, cell*c2)
{
  // ATTENTION 2 c1 et c2 : maillons_successifs, c1 en 1er
  assert(c1!=NULL);
  assert(c2!=NULL);
  void aux(cell*c1, cell*c2)
  {
    cell*tmp=c1->addr_p;
    c1->addr_n=c2->addr_n;
    c1->addr_p=c2;
    c2->addr_n=c1;
    c2->addr_p=tmp;
  };
    
  //printf("Avant : %f  et   %f\n", c1->val, c2->val);
  if(c1->addr_p==NULL)
    {
      list->frst=c2;
      if(c2->addr_n!=NULL)c2->addr_n->addr_p=c1;
      aux(c1, c2);
    }
  else
    {
      if(c2->addr_n!=NULL)c2->addr_n->addr_p=c1;
      if(c1->addr_p!=NULL)c1->addr_p->addr_n=c2;
      aux(c1, c2);
    }
      
  /*
      c2->addr_n->addr_p=c1;
  //c1->addr_p->addr_n=c2;
  */

  //printf("Apres : %f  et %f\n\n", c1->addr_p->val, c2->addr_n->val);
}


void ldc_tri_insertion(ldc *list)
{
  cell*point;
  for(int i=1;i<list->lg;i++)
    {
     point=ldc_travel(list, i);
     //printf("Val point : %f\n", point->val);
     while(*((elem_t*)point->val)<*((elem_t*)point->addr_p->val))
       {
	 //printf("\tVal du pt : %f\n\n____________________", point->val);
	 ldc_swap(list, point->addr_p, point);
	 if(point->addr_p==NULL) break;
	 
       };
    };
 
}


int main()
{
  // PROF: pour tester du "vrai" polymorphisme, mélanger des tests avec les listes sur des entiers, des flottants, des caractères...
  // et du coup pas de #define elem_t, il faudra adapter vos affichages à chaque liste et c'esst de la responsabilité de l'utilisateur de votre librairie polymorphe
  srand(time(0));
  ldc *jojo=ldc_create();
  for(int i=0 ; i<11;i++)
    {
      elem_t * j=malloc(sizeof(float));
      *j=i;
      ldc_push(jojo, j);
    };
  ldc_print(jojo);
  // PROF: erreur ici, cet affichage ne marche pas car ldc_pop renvoie un pointeur void *. Il faut le transtyper puis récupérer la valeur
  printf("Tete enlevee : %f\nNouvelle liste :\n", ldc_pop(jojo));
  ldc_print(jojo);
  

  printf("Test : fonction insert  :\n");
  elem_t*nine=malloc(sizeof(float));
  *nine=999;
  ldc_insert_ith(jojo, nine, 0);
  ldc_print(jojo);
  

  printf("Test fonction delete :\n");
  ldc_delete_ith(jojo, 0);
  ldc_print(jojo);
  
  //______________________Deux_______________

  elem_t * ths=malloc(sizeof(float));
  *ths=9999;
  printf("\nTest no 2: fonction insert  :\n");
  ldc_insert_ith(jojo, ths, 5);
  ldc_print(jojo);
  

  printf("Test no 2: fonction delete :\n");
  ldc_delete_ith(jojo, 5);
  ldc_print(jojo);

  
  printf("\nTest fonction inverse :\n");
  ldc_reverse(jojo);
  ldc_print(jojo);

  //__________Test tri_insertion______________

  ldc* jaja=ldc_create();
  for(int i=0 ; i<100;i++)
    {
      elem_t * j=malloc(sizeof(float));
      *j=rand()%100;
      ldc_push(jaja, j);
    };

  printf("Liste non triée :\n");
  ldc_print(jaja);
  printf("Liste triée\n");
  ldc_tri_insertion(jaja);
  ldc_reverse(jaja);
  ldc_print(jaja);

  
  

    






  free(jaja);
  free(jojo);
}
