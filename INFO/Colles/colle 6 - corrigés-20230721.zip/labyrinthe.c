#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>
#include <time.h>

#define elt_type int
#define elt_fmt "%d\n"

struct s_stack
{
  int siz; // taille courante de la stacke
  int siz_max; // taille maximale possible
  elt_type *tab; // tableau contenant les valeurs (séquentielles) de la stacke
};

typedef struct s_stack stack;

stack *stack_create(int s_max)
{
  stack *s = malloc(sizeof(stack));
  s->siz = 0;
  s->siz_max = s_max;
  s->tab = malloc(s_max*sizeof(elt_type));

  return s;
}

bool stack_is_empty(stack *s)
{
  assert(s != NULL);
  return (s->siz == 0);
}

int stack_length(stack *s)
{
  assert(s != NULL);
  return s->siz;
}

void stack_push(stack *s, elt_type v)
{
  assert(s != NULL);
  assert(s->siz < s->siz_max-1);
  
  s->tab[s->siz] = v;
  s->siz = s->siz+1;

  return;
}

elt_type stack_top(stack *s)
{
  assert(s != NULL);
  assert(s->siz > 0);
  return s->tab[s->siz-1];
}

elt_type stack_pop(stack *s)
{
  assert(s != NULL);
  assert(s->siz > 0);
  elt_type v = s->tab[s->siz-1];
  s->siz = s->siz-1;

  return v;
}

void stack_print(stack *s)
{
  assert(s != NULL);
  printf("Hauteur de la pile %d\n", stack_length(s));
  printf("-------\n");
  for (int i = s->siz-1; i >= 0; i--)
    printf(elt_fmt, s->tab[i]);
  printf("-------\n");
  printf("\n");
}

void stack_delete(stack *s)
{
  assert(s != NULL);
  s->siz = 0;
}

void stack_free(stack **addr_s)
{
  assert(addr_s != NULL);
  stack *s = *addr_s;
  if (s->tab != NULL)
    free(s->tab);
  free(s);
  *addr_s = NULL;
}














void init(int *lab, int siz)
{
  int i;
  float alea = (float)rand()/RAND_MAX;
  for(i=0; i<siz*siz; i++)
    {
      alea = (float)rand()/RAND_MAX;
      if(alea < 0.7)
	lab[i] = 0;
      else
	lab[i] = 1;
    }
}
void idx2couple(int idx, int *i, int *j, int siz_lab)
{
  *i = idx/siz_lab;
  *j = idx%siz_lab;
  return;
}

void print_soluce(stack *s)
{
  assert(s != NULL);
  printf("Chemin à parcourir :\n");
  printf("-------\n");
  for (int i =  0; i < s->siz; i++)
    printf(elt_fmt, s->tab[i]);
  printf("-------\n");
  printf("\n");
}

int neighbours(int idx, int *lab, int siz_lab, int *neight)
{
  int i;
  int j;
  int k;
  int count = 0;
  idx2couple(idx, &i, &j, siz_lab);
  //printf("i et j %d %d\n", i, j);
  if(i!=0 && i!=siz_lab-1)
    {
      for(k=-1; k<2; k = k + 2)
	{
	  if(lab[ (i+k)*siz_lab + j] == 0)
	    {
	      neight[count] = (i+k)*siz_lab + j;
	      count = count + 1;
	      //printf("coucou");
	    }
	}
    }
  if(j!=0 && j!=siz_lab-1)
    {
      for(k=-1; k<2; k = k + 2)
	{
	  //printf("k %d \n", k);
	  //printf("%d\n", lab[ i*siz_lab + (j+k)]);
	  if(lab[ i*siz_lab + (j+k)] == 0)
	    {
	      neight[count] = i*siz_lab + (j+k);
	      count = count + 1;
	      //printf("ici");
	    }
	}
    }
  if(i==0)
    {
      if(lab[siz_lab + j] == 0)
	{
	  //printf("%d\n", siz_lab + j);
	  neight[count] = siz_lab + j;
	  count = count + 1;
	  //printf("am\n");
	}
    }
  else if(i==siz_lab-1)
    {
      if(lab[(i-1)*siz_lab + j] == 0)
	{
	  neight[count] = (i-1)*siz_lab + j;
	  count = count + 1;
	  //printf("stram\n"); fflush(stdout);
	}
    }
  if(j==0)
    {
      if(lab[i*siz_lab + (j+1)] == 0)
	{
	  neight[count] = i*siz_lab + (j+1);
	  count = count + 1;
	  //printf("gram\n");
	}
    }
  else if(j==siz_lab-1)
    {
      if(lab[i*siz_lab + (j-1)] == 0)
	{
	  neight[count] = i*siz_lab + (j-1);
	  count = count + 1;
	  //printf("encore\n");
	}
    }
  return count;
}



bool compute_solution(int idx_start, int idx_end, int *lab, int siz_lab)
{
  stack *soluce = stack_create(500);
  int neigh[4];
  int count;
  bool find = false;

  int current = idx_start;
  stack_push(soluce, current);
  
  while(find==false && stack_length(soluce) != 0)
    {
      current = stack_top(soluce);
      //printf("current %d\n", current); fflush(stdout);
      lab[current] = -1;
      if(current == idx_end)
	{
	  find = true;
	}
      count = neighbours(current, lab, siz_lab, neigh);
      //printf("neigh %d", neigh[0]);
      if(count>0)
	{
	  stack_push(soluce, neigh[0]);
	  //printf("ici\n");
	}
      if(count == 0)
	{
	  stack_pop(soluce);
	  //printf("là\n");
	}
      //stack_print(soluce);
    }
  if(find == true)
    {
      stack_push(soluce, idx_end);
      print_soluce(soluce);
    }
  stack_free(&soluce);
  return find;
}
  
void print_lab(int *lab, int siz)
{
  int i = 0;
  for(i=0; i<siz*siz; i++)
    {
      printf("%d ", lab[i]);
      if((i+1)%siz == 0)
	printf("\n");
    }
}

int main(void)
{
  srand(time(NULL));
  int siz_lab = 15;
  int test_lab[siz_lab*siz_lab];
  init(test_lab, siz_lab);
  print_lab(test_lab, siz_lab);
  
  //int neigh[4];
  //int count = neighbours(0, test_lab, siz_lab, neigh);
  //printf("neigh %d %d\n", neigh[0], neigh[1]);
  //printf("%d\n", count);
  //test_lab[0] = -1;
  //count = neighbours(1, test_lab, siz_lab, neight);
  //printf("%d\n", count);
  compute_solution(0, 224, test_lab, siz_lab);
  
  return 0;
}
