(* EXERCICE 1 *)

(* Question 1 *)

let recherche_dichotomique tab x =
  let n = Array.length tab in
  let rec boucle i j =
    if i >= j-1 then 
      if tab.(i) = x then i
      else if tab.(j) = x then j
      else -1
    else let k = (i + j) / 2 in
      if tab.(k) > x then boucle i k
      else boucle k j
  in boucle 0 (n-1) ;;

recherche_dichotomique [|2;4;5;7;10|] 6 ;;
recherche_dichotomique [|2;4;5;7;10|] 7 ;;

(* O(log(n)) tests où n est la longueur du tableau *)

(* En effet la complexité vérifie 
C(0) = 0 et C(n) <= C(n/2) + 2
donc C(n) = O(log n)
*)

(* Question 2 *)

let recherche_prefixe tab x debut fin =
  let rec boucle i j =
    if i >= j-1 then 
      if tab.(i) = x then i
      else if tab.(j) = x then j
      else -1
    else let k = (i + j) / 2 in
      if tab.(k) != x then boucle i k
      else boucle k j
  in boucle debut fin ;;

recherche_prefixe [|23;23;23;75;100|] 2 0 4 ;;
recherche_prefixe [|2;2;2;7;10|] 2 0 4 ;;
recherche_prefixe [|2;2;2;2;10|] 2 0 4 ;;
recherche_prefixe [|2;2;2;2;2;9|] 2 0 4 ;;

let recherche_suffixe tab x debut fin =
  let rec boucle i j =
    if i >= j-1 then 
      if tab.(i) = x then i
      else if tab.(j) = x then j
      else -1
    else let k = (i + j) / 2 in
      if tab.(k) != x then boucle k j 
      else boucle i k
  in boucle debut fin ;;

recherche_suffixe [|23;23;23;23;23|] 23 0 4 ;;
recherche_suffixe [|2;2;23;23;23|] 23 0 4 ;;
recherche_suffixe [|2;3;3;23;23|] 23 0 4 ;;
recherche_suffixe [|2;3;3;3;23|] 23 0 4 ;;

let recherche_intervalle tab x =
  let n = Array.length tab in
  let m = recherche_dichotomique tab x in
  if m = -1 then (-1,-1)
  else
  (recherche_suffixe tab x 0 m, recherche_prefixe tab x m n) ;;

recherche_intervalle [|2;3;23;23;23|] 23 ;;
recherche_intervalle [|2;23;23;23;234|] 23 ;;
recherche_intervalle [|3;23;23;23;33|] 23 ;;
recherche_intervalle [|23;23;23;23;23|] 24 ;;

(* O(log(n)) où n est la longueur du tableau *)

(* EXERCICE 2 *)

(* Question 3 *)

let rec puissance_naive x n =
  if n = 0 then 1
  else if n = 1 then x
  else let y = puissance_naive x (n-1) in y * x ;;

(* Question 4 *)

let rec puissance x n =
  if n = 0 then 1
  else if n = 1 then x
  else let y = puissance x (n/2) in
    if n mod 2 = 0 then y * y else y * y * x ;;

(* O(log(n)) multiplications *)

(* Question 5 *)

let rec nb_bits n =
  if n = 0 then 0
  else if n = 1 then 1
  else let y = nb_bits (n/2) in y + 1 ;;

let binaire n =
  let logn = nb_bits n in
  let tab_bin = Array.make logn 0 in
  let rec boucle n i =
  if n = 0 then ()
  else if n = 1 then tab_bin.(i) <- 1
  else 
    (if n mod 2 = 1 then tab_bin.(i) <- 1 ; boucle (n/2) (i+1))
  in 
  boucle n 0 ; 
  tab_bin ;;

binaire 8 ;;
binaire 13 ;;
binaire 41 ;;