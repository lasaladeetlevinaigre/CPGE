let liste_test = [-1; 1; -3; 4; -1; 2; 1; -5; 4];;
let liste_test_2 = [1; -4; 1; 5; -7; 0];;


(* Q1 *)
let max_sum_naive l =
  let len = -1 + List.length l in
  let sum = ref 0 in
  for i = 0 to len do
    for j = 0 to len do
      let tmp = ref 0 in
      for k = i to j do
        tmp := !tmp + List.nth l k;
      done;
      if !sum < !tmp then sum := !tmp 
    done;
  done;
  !sum;;

(* test de max_sum_naive *)
Printf.printf "========== TEST (max_sum_naive) ==========\n";;
Printf.printf "%d\n" (max_sum_naive liste_test_2);;



(* Q5 *)
let rec max_liste_generique ord_func l = match l with
| [] -> failwith "max_liste_generique: soulèvement d'erreur évitable par utilisation de `Option`... mais la liste est vide."
| hd :: [] -> hd
| hd :: tl ->
   let max = max_liste_generique ord_func tl in
     if ord_func max hd then max
     else hd;;

(* test de max_liste_generique *)
Printf.printf "========== TEST (max_liste_generique) ==========\n";;
Printf.printf "%d\n" (max_liste_generique (>) liste_test);;
Printf.printf "%s\n" (max_liste_generique (<) ["une valeur"; "le maximum"; "une 2ème valeur"]);;



(* Q6 *)
let max_sum_kadane l =
  let rec aux l last acc = match l with
  | [] -> last :: acc
  | hd :: tl when last > 0 -> aux tl (last + hd) (last :: acc)
  | hd :: tl -> aux tl hd (last :: acc)
  in match l with
     | [] -> failwith "func max_sum_kadane: la liste est vide."
     | hd :: tl -> max_liste_generique (>) (aux tl hd []);;

(* test de max_sum_kadane *)
Printf.printf "========== TEST (max_sum_kadane) ==========\n";;
Printf.printf "%d\n" (max_sum_kadane liste_test);;



(* Q8 *)
let kadane l =
  let rec max_liste l = match l with
    | [] -> failwith "La liste est vide."
    | hd :: [] -> hd
    | (hd, hd2) :: tl ->
       let max = max_liste tl in
       let max_hd, max_hd2 = max in
         if max_hd > hd then (max_hd, max_hd2)
         else (hd, hd2)
  in let rec aux l last last2 acc = match l with
    | [] -> (last, last2) :: acc
    | hd :: tl when last > 0 -> aux tl (last + hd) (hd :: last2) ((last, last2) :: acc)
    | hd :: tl -> aux tl hd [hd] ((last, last2) :: acc)
  in let rec rev l acc = match l with
       | [] -> acc
       | hd :: tl -> rev tl (hd :: acc)
  in match l with
     | [] -> failwith "func kadane: la liste est vide."
     | hd :: tl -> let _, max = max_liste (aux tl hd [hd] [])
                   in rev max [];;

(* test de kadane *)
let print_tab l =
  let rec aux l = match l with
  | [] -> Printf.printf "]\n"
  | hd :: [] -> Printf.printf "%d]\n" hd
  | hd :: tl -> (Printf.printf "%d, " hd; aux tl)
  in Printf.printf "["; aux l;;

Printf.printf "========= TEST (kadane) ==========\n";;
print_tab (kadane liste_test);;
