
let rec puissance_naive_rec n x =
  match n with
  |n when n<0 -> failwith("Erreur, n est negatif")
  |0-> 1.
  |_ -> puissance_naive_rec x (n-1) *.x
;;



let rec puissance_rec n x =
  match (n, n mod 2) with
  |(n, _) when n < 0 -> failwith"Erreur, n negatif"
  |(0, _) -> 1.
  |(_, 0)  -> (puissance_rec x (n/2)) *. (puissance_rec x (n/2))
  | _ -> (puissance_rec x (n/2)) *. (puissance_rec x (n/2)) *. x
;;

(* O(log(n)) multiplications *)

puissance_rec 2. 3;;
puissance_rec (-3.) 4;;


let  nb_bits n =
  if n = 0 then 1 else 
  let rec aux acc n =
    match n with
    |p when p < 0 -> failwith "Erreur : x non traite"
    |0 -> acc
    |_-> aux (acc+1) (n/2)
  in
  aux 0 n ;;

nb_bits 0;;
nb_bits 4;;
nb_bits 32;;

let binaire n =
  let logn = nb_bits n in
  let tab_bin = Array.make logn 0 in
  let rec boucle n i = (* boucle ecrite de maniere recursive cf fin de la sequence 6 sur Moodle *)
  if n = 0 then () (* deja mis a 0 *)
  else if n = 1 then tab_bin.(logn-1-i) <- 1
  else 
    (if n mod 2 = 1 then tab_bin.(logn-1-i) <- 1 ; boucle (n/2) (i+1))
  in 
  boucle n 0 ; 
  tab_bin ;;

binaire 8 ;;
binaire 13 ;;
binaire 41 ;;

(* Dans l'algo d'exponentiation, si on décompose la puissance n en binaire, et si on note p0 le nombre de 0 et p1 le nombre de 1 de cette décomposition, alors le nombre de multiplications effectuées est égal à
C(n) = p0 + 2*p1
 *)

let puissance_iter n0 x =
  let n   = ref n0 in
  let acc = ref 1. in
  let a   = ref x in
  while (!n > 0)
  do
    if (!n mod 2 = 1) then
      acc := !acc  *. !a;
  
    a := (!a *. !a);
      
    n := !n / 2
  done;
  !acc
;;

puissance_iter 3 2.0;;
puissance_iter 6 2.0;;
puissance_iter 8 2.0;;
puissance_iter 1 2.0;;
