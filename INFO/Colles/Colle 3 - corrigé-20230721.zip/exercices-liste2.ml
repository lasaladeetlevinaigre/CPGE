let rec merge l1 l2 =
  match (l1,l2) with
  | (_ , []) -> l1
  | ([], _ ) -> l2
  | (h1::t1 , h2::t2) when h1 < h2 -> h1::merge t1 (h2::t2)
  |  (h1::t1 , h2::t2)             -> h2::merge t2 (h1::t1);;

merge [1;5;7] [2;4;6;8;10];;
merge [1;1;1] [1;1;1;1];;
merge [] [5];;
merge [5] [];;
merge [] [];;



let rec max_liste_generique f l =
  match l with
  | [] -> failwith "pas d'element a comparer"
  | [u] -> u
  | h::t when f h (max_liste_generique f t) -> h
  | h::t ->  max_liste_generique f t;;

let f1 x y = x > y;;
let f2 x y = x < y ;;
max_liste_generique f1 [4;5;3];;
max_liste_generique f2 [];;
max_liste_generique f2 [4;5;3];;


let rec split n l =
  match (n,l) with
 | (n , _)  when n < 0 -> failwith "entier négatif en paramètre"
 | (n , [])  -> ( [] , [] ) (* code resilient *)
 | (0 , l ) -> ( [] , l)
 | (n , h::t ) -> let (l1,l2) = split (n-1) t in
                  (h::l1,l2);; 

 
split 2 [1;2;3;4;5;6;5];;
split 1 [];;
split (-1) [];;
split (-1) [1;2;3];;
split 0 [];;
split 0 [1;2;3];;
split 1 [1;2;3];;


let dispo l =
  let n = List.length l in 
  let est_dispo = Array.make (n+1) true in
  let barre_entier v = if v >= 0 && v < n then est_dispo.(v) <- false in
  List.iter barre_entier l;
  (* boucle écrite sous forme iterative... cf toute fin de la seq 6... mais vous pouvez aussi l'écrire en iteratif classique avec un while *)
  let rec trouve_premier_dispo i = if est_dispo.(i) then i else trouve_premier_dispo (i+1) in
  trouve_premier_dispo 0
;;
(* complexite linéaire*)

dispo [-3;1;-2;0];;
  
dispo [-3; 3; 5; 7; 8; 4; 1;-2;0; 2];;
