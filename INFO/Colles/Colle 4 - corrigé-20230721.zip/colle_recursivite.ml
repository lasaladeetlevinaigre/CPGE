let rec somme l1 l2 =
  match (l1, l2) with
  | (_, [])          -> []
  | ([], _)          -> []
  | (t1::q1, t2::q2) -> t1+t2::(somme q1 q2)
;;

somme [1;1;1] [2;2;2;2];;
somme [] [];;
somme [0;1;2] [10];;
somme [1;2;3;4;5;6] [6;5;4;3;2;1];;



let rec concatene_miroir l1 l2 =
  match (l1, l2) with
  | ([], [])    -> []       
  | (t1::q1, _) -> (concatene_miroir q1 l2)@[t1]
  | (_, t2::q2) -> (concatene_miroir [] q2)@[t2]
;;

concatene_miroir [1;2;3;4] [5;6;7;8];;
concatene_miroir [] [];;
concatene_miroir [10;9;8;7;6] [5;4;3;2;1;0];;
concatene_miroir [10;9;8;7] [];;




let rec aux n acc =
  match n with
  | 0 -> []
  | _ -> aux (n/2) acc@[n mod 2]
;;
let binaire n =
  aux n []
;;
binaire 47;;
binaire 2;;
binaire 255;;



let dispo l =
  let n = List.length l in 
  let est_dispo = Array.make (n+1) true in
  let barre_entier v = if v >= 0 && v < n then est_dispo.(v) <- false in
  List.iter barre_entier l;
  (* boucle écrite sous forme iterative... cf toute fin de la seq 6... mais vous pouvez aussi l'écrire en iteratif classique avec un while *)
  let rec trouve_premier_dispo i = if est_dispo.(i) then i else trouve_premier_dispo (i+1) in
  trouve_premier_dispo 0
;;
(* complexite linéaire*)

dispo [-3;1;-2;0];;
  
dispo [-3; 3; 5; 7; 8; 4; 1;-2;0; 2];;



type couleur = Rouge | Blanc | Bleu;;


let rec modification l =
  match l with
  | [] -> ([], false)
  | Blanc::Rouge::q -> let (l1, _) = modification (Blanc::q) in (Rouge::l1, true)
  | Bleu::Rouge::q  -> let (l1,_) = modification (Bleu::q) in (Rouge::l1, true)
  | Bleu::Blanc::q  -> let (l1,_) = modification (Bleu::q) in (Blanc::l1, true)
  | t::q            -> let (l1,b) = modification q in (t::l1, b)
;;

modification [Rouge;Blanc;Bleu;Bleu];;
modification [Bleu;Rouge;Blanc;Bleu;Rouge];;
modification [Bleu;Blanc;Rouge;Blanc;Rouge;Bleu];;
modification [];;

let rec tri_drapeau l =
  let (l1, b) = modification l in
  if b then tri_drapeau l1 else l
;;

tri_drapeau [Rouge;Blanc;Bleu;Bleu];;
tri_drapeau [Bleu;Rouge;Blanc;Bleu;Rouge];;
tri_drapeau [Bleu;Blanc;Rouge;Blanc;Rouge;Bleu];;
tri_drapeau [];;
