//Il est attendu de la part de l'utilisateur un fichier texte comprenant 3 lignes. Une premiere ligne avec 1 entier naturel correspond à l'effectif de la série statistique, une deuxième ligne composée d'autant de nombres réels que l'effectif espacé par un espace et une dernière ligne correspondant au fréquences de la série (entier naturel)
//Les test ont été laisser en argument.

#include<stdio.h>
#include<stdlib.h>
#include<assert.h>
#include<math.h>

int nombre_echantillons(char* path) //renvoie l'effectif de la série en lisant la première ligne
{
  FILE *f = fopen(path, "r");
  if(f == NULL)
    {
      return -1;
    }
  int amount_of_values = 0;
  fscanf(f, "%d", &amount_of_values);
  
  fclose(f);
  return amount_of_values;
}

void recovery(char* path, float** ptab_val, int** ptab_freq, int amount_of_values) //remplie les tableau de valeur et fréquence en lisant la deuxieme et troisieme ligne
{
  FILE *f = fopen(path, "r");

  float current_value = 0.;
  int current_freq = 0;
  fscanf(f, "%d", &current_freq);


  // PROF: essayez qd meme d'appliquer les principes de la prog
  // défensive: l'utilisateur peut très bien avoir crée un fichier en mettant  // qu'il y 8 valeurs, et en fait n'en donner que 7... vérifiez bien à chaque foid que vous n'êtes pas prématurement en bout de fichier...
  int i = 0;
  for(i=0; i<amount_of_values; i++)
    {
      fscanf(f, "%f", &current_value);
      (*ptab_val)[i] = current_value;
    }
  for(i=0; i<amount_of_values; i++)
    {
      fscanf(f, "%d", &current_freq);
      (*ptab_freq)[i] = current_freq;
    }
  fclose(f);
}

float max(float* tab_val, int amount_of_values) //renvoie plus grande valeur de la série
{
  int i = 1;
  float max_value = tab_val[0];
  for(i=1; i<amount_of_values; i++)
    {
      if(tab_val[i]>max_value)
	{
	  max_value = tab_val[i];
	}
    }
  return max_value;
}

float moyenne(float* tab_val, int* tab_freq, int amount_of_values) //renvoie la moyenne pondérée calculée de l'effectif
{
  float sum_values_weight = 0;
  float sum_freq = 0;
  float mean = 0;
  int i = 0;
  for(i=0; i<amount_of_values; i++)
    {
      sum_values_weight += tab_val[i]*tab_freq[i];
      sum_freq += tab_freq[i];
    }
  //printf("%f %f\n", sum_values_weight, sum_freq);
  mean = sum_values_weight / sum_freq;
  return mean;
}

float ecart_type(float* tab_val, int* tab_freq, float amount_of_values, float mean) //renvoie l'écart-type calculé de la série
{
  int i = 0;
  float gap = 0;
  float sum_freq = 0;
  for(i=0; i<amount_of_values; i++)
    {
      gap += (tab_freq[i])*(mean-tab_val[i])*(mean-tab_val[i]);
      sum_freq += tab_freq[i];
      //printf("%f\n", gap);
    }
  gap = gap / sum_freq;
  //printf("%f\n", gap);
  gap = sqrt(gap);

  return gap;
}

int main(int argc, char** argv)
{
  assert(argc == 2);
  char* path = argv[1];

  int amount_of_values = nombre_echantillons(path);
  assert(amount_of_values != 1);
  //printf("amount of values = %d\n", amount_of_values);

  float* tab_val = (float*)malloc(sizeof(float)*amount_of_values);
  int* tab_freq = (int*)malloc(sizeof(int)*amount_of_values);

  recovery(path, &tab_val, &tab_freq, amount_of_values);

  //printf("valeur max : %f\n", max(tab_val, amount_of_values));
  //printf("moyenne : %f\n", moyenne(tab_val, tab_freq, amount_of_values));

  float maxi = max(tab_val, amount_of_values);
  float mean = moyenne(tab_val, tab_freq, amount_of_values);
  float gap = ecart_type(tab_val, tab_freq,  amount_of_values, mean);

  printf("On étudie les données du documents '%s':\nvaleur max: %f\nmoyenne: %f\nécart-type: %f\n", path, maxi, mean, gap);
  
  free(tab_val);
  free(tab_freq);
  return 0;
}

  
