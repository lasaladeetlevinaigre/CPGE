let nombre_de_bits p0 =
  let m = ref 1 in
  let p = ref p0 in
  while (!p/2 > 0) do
    m := !m + 1;
    p := !p / 2
  done;
  !m 
;;

nombre_de_bits 8;;
nombre_de_bits 32;;

let dec2bin p0 =
  let m = nombre_de_bits p0 in
  let bits = Array.make m 0 in
  let p = ref p0 in 
  for idx = 0 to m-1 do  
    bits.(m-1-idx) <- !p mod 2;
    p := !p / 2
  done;
  bits
;;

dec2bin 8;;
dec2bin 32;;
dec2bin 93;;

let rec nombre_de_bits_ref p0 =
  match p0/2 with
  | 0 -> 1
  | _ -> 1 + nombre_de_bits(p0/2)
;;

nombre_de_bits_rec 8;;

(* Fonction récursive terminale permettant d'éviter l'empilement d'un nouveau bloc d'activation à chaque appel *)
let nombre_de_bits_rec_term p0 =

  let rec aux_nombre_de_bits_rec_term acc p0 =
    match p0/2 with
    | 0 -> acc
    | _ -> aux_nombre_de_bits_rec_term (acc + 1) (p0/2)
  in
  
  aux_nombre_de_bits_rec_term 1 p0
;;

nombre_de_bits_rec_term 8;;
nombre_de_bits_rec_term 32;;


let rec dec2bin_rec p0 =
  match p0 with
  |0 -> [0]
  |1 -> [1]
  |_ -> (dec2bin_rec (p0/2))@[p0 mod 2]
;;
dec2bin_rec 8;;

let dec2bin_rec_term p =

  let rec aux_dec2bin_rec_term l p0 =
    match p0 with
    |0 -> l
    |_ -> ( aux_dec2bin_rec_term ((p0 mod 2)::l) (p0/2) )
  in
    aux_dec2bin_rec_term [] p
;;
dec2bin_rec_term 8;;
dec2bin_rec_term 32;;
