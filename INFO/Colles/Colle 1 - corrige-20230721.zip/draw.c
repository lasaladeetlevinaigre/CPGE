#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

void draw(int n)
{
  assert(n > 0);
  
  printf("\n");
  for (int i = 0 ; i < n; i++)
  {
    for (int j = 0; j < n; j++)
    {
      if ( (i&j) == 0)
	printf("* ");
      else
	printf("  ");
    }
    printf("\n");
  }
  printf("\n");
}


int main(int argc, char *argv[])
{
  assert(argc == 2);

  int n = atoi(argv[1]);

  draw(n);
  
  return 0;
}
