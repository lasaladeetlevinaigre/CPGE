let rec genere_liste_alea a b n =
  match n with
  | n when n < 0 -> failwith "Taille negative"
  | 0 -> []
  | _ -> (a + Random.int (b-a))::(genere_liste_alea a b (n-1))


let l1 = genere_liste_alea 0 20 25;;


let rec maxi_lst l =
  match l with
  | [] -> failwith "Pas d'element max dans une liste vide"
  | [v] -> v
  | h::t -> let m = (maxi_lst t) in if ( h > m ) then h else m
;;

let l1 = [ 4; 7; -3; 1; 18; 1];;
maxi_lst l1;;

let rec square_lst l =
  match l with
  |[] -> []
  |h::t -> (h*h)::(square_lst t)
;;

square_lst l1;;

let rec split l n =
  match (l, n) with
  |(_   ,n) when n < 0 -> failwith "Erreur"
  |([]  ,0)            -> ([],[])
  |([]  ,n) when n > 0 -> failwith "Erreur"
  |(h::t, 1)           -> ([h], t)
  |(h::t, n)           -> (h::(fst (split t (n-1))), snd (split t (n-1)))
;;

let l1 = [ 1; 2; 3; 4];;
split l1 3;;

(* autre possibilite, à étudier! La fonction List.rev est l'équivalent du miroir que nous avons codé *)
let split l n =
  let rec aux i l1 l2 =
    match (i, l1) with
    | (0,_) | (_, []) -> (List.rev l2, l1)
    | (_, h::t) -> aux (i-1) t (h::l2)
  in
  aux n l []
;;


let rec shuffle l1 l2 =
  match (l1, l2) with
  | ([], []) -> []
  | ([], _) -> l2
  | (_, []) -> l1
  | (h1::t1, h2::t2) -> h1::h2::(shuffle t1 t2)
;;

let l1 = [1;3;5];;
let l2 = [2;4;6;8;10];;
shuffle l1 l2;;
