let genere_tab_alea a b n =
  assert (a < b);
  assert (n >= 0);
  let tab = Array.make n 0 in
  for i = 0 to (n-1) do
    tab.(i) <- a + (Random.int (b-a))
  done;
  tab
;;

genere_tab_alea 2 7 10;;
genere_tab_alea 2 3 10;;
genere_tab_alea 2 3 0;;
genere_tab_alea 2 3 (-1);;

let echange tab i j =
  let tmp = tab.(i) in
  (
    tab.(i) <- tab.(j);
    tab.(j) <- tmp
  )
;;

let t = genere_tab_alea 2 7 10;;
echange t 2 5;;
t;;


let idx_min tab i j =
  assert(i <= j);
  let imin = ref i in
  let emin = ref tab.(!imin) in
  for k = i to j do
    if (tab.(k) < !emin) then
      (
        imin := k;
        emin := tab.(!imin)
      )
  done;
  !imin
;;

t;;
idx_min t 2 7;;

let tri_insertion tab =
  let n = Array.length tab in
  for i=0 to (n-1) do
    let imin = idx_min tab i (n-1) in
    Printf.printf "Echange tab[%d] tab[%d]\n" i imin;
    echange tab i imin;
  done
;;

let t = genere_tab_alea 1 50 20;;
tri_insertion t;;
t;;
