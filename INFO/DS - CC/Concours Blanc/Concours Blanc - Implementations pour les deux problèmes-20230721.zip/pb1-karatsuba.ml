(* compute degree of polynom = length of the list *)
(* recursive terminale. Complexite lineaire *)
let deg p =
  let rec aux p acc =
  match p with
  |[] -> acc
  |a0::pp -> aux pp (acc+1)
  in
  match p with
  | [] -> failwith "empty polynom!"
  |_ -> aux p (-1)
;;

(* algo d'exponentiation rapide, implemente sous sa forme terminale *)
let pow x n =
  let rec aux x n acc =
    match n with
    | 0 -> acc
    | n when  (n mod 2 = 0) -> aux (x *. x) (n/2) acc
    |_ -> aux (x *. x) (n/2) (x *. acc)
  in
  if (n < 0) then
    failwith "negative exponant"
  else
    aux x n 1.
;;

pow 2. 8;;

(* evaluation naive d'un polynome utilisant l'exponentiation rapide *)
(* complexite d= degre du polynome. T(k) = T(k+1) + log(k)  k<=d ==> somme (log(k))(k=0 à d) = dlg(d) !*)
let polynom_naive_eval p x =
  let rec aux p x k acc =
    match (k,p) with
    |(k, _) when (k < 0) -> failwith "problem"
    |(_, []) -> acc
    |(k, ak::pp) -> aux pp x (k+1) (acc +. ak *. (pow x k))
  in
  aux p x 0 0.
;;


let p = [1.; 1.; 0.; 0.5; 0.; 1.];;
polynom_naive_eval p 1.;;
polynom_naive_eval p 2.;;

(* evaluation d'un polynome avec la methode de Horner: complexité linéaire! *)
let polynom_horner_eval p x =
   let rec aux prev x acc =
     match prev with
     |[] -> acc
     |ak::pp -> aux pp x (ak +. x *. acc)
   in
   aux (List.rev p) x 0.
;;  
polynom_horner_eval p 1.;;

polynom_horner_eval p 2.;;


(* addition de deux polynomes complexité linéaire *)
let polynom_add p q =
  let rec aux p q acc = 
    match (p, q) with
    |([],[]) -> acc
    |([], bk::qq) -> aux [] qq (bk::acc) 
    |(ak::pp, []) -> aux pp [] (ak::acc) 
    |(ak::pp, bk::qq) -> aux pp qq ( (ak+.bk)::acc )
  in
  List.rev (aux p q [])
;;
      
let p = [1.;1.;1.];;
let q = [0.;1.;0.;1.];;
polynom_add p q;;

(* soustraction de deux polynomes complexité linéaire *)
let polynom_sub p q =
  let rec aux p q acc = 
    match (p, q) with
    |([],[]) -> acc
    |([], bk::qq) -> aux [] qq ((-1.*. bk)::acc) 
    |(ak::pp, []) -> aux pp [] (ak::acc) 
    |(ak::pp, bk::qq) -> aux pp qq ( (ak-.bk)::acc )
  in
  List.rev (aux p q [])
;;
      
let p = [1.;1.;1.];;
let q = [0.;1.;0.;1.];;
polynom_add p q;;

(* multiplication naive de deux polynomes: version iterative *)
(* complexité: p*q/2 --> quadratique!!*)
let polynom_naive_mult p q =
  let degp = deg p in
  let degq = deg q in
  let pp = Array.of_list p in
  let qq = Array.of_list q in
  let deg_mult = degp+degq in
  let res = Array.make (deg_mult+1) 0. in
  let cnt = ref 0 in
  for k=0 to deg_mult do
    Printf.printf "\nk=%d: " k;
    let sum = ref 0. in
    for i = (max 0 (k-degq)) to (min k degp) do
      Printf.printf "(%d,%d)" i (k-i);
      sum := !sum +. pp.(i) *. qq.(k-i);
      cnt := !cnt + 1
    done;
    res.(k) <- !sum (* on stocke le coefficient ck *)
  done;
  Printf.printf "\nNombre d'operations =%d\n" !cnt;
  res
;;
  
let p = [1.;1.;1.];;
let q = [0.;1.;0.;1.; 7.1; 3.];;
polynom_naive_mult p q;;

let q = [1.;1.;1.];;
let p = [0.;1.;0.;1.; 7.1; 3.];;
polynom_naive_mult p q;;

(* division euclidienne d'un polynome par X^m: P = P1*X^m + P2 --> renvoie (P2,P1) *)
(* complexité linéaire *)
let decomp p m =
  let rec aux p m k acc =
    match (p, k) with
    |([],_) -> acc
    |(ak::pp, k) when k >= m -> aux pp m (k+1) (ak::(fst acc), snd acc)
    |(ak::pp, k) when k < m -> aux pp m (k+1) (fst acc, ak::(snd acc))
    |_ -> failwith "pb"
  in
  let (p1rev, p2rev) = aux p m 0 ([], []) in
  (List.rev p1rev, List.rev p2rev)
;;

let p = [1.;1.;1.;1.;1.;2.;4.];;
decomp p 2;;


max;;

let polynom_print p =
  List.iter (fun x -> Printf.printf "%f " x) p;
  Printf.printf "\n"
;;


(* multiplication d'un polynome par X^m --> décalage du stockage de ses coeff de m zéros vers la droite *)
let polynom_offset p m =
  let rec aux p m k acc =
    match (p,k) with
    |(_, k) when k < m -> aux p m (k+1) (0.::acc)
    |([],_) -> acc
    |(a::pp, k)  ->  aux pp m (k+1) (a::acc)
  in
  List.rev (aux p m  0 [])
;;
polynom_offset [1.; 2.; 3.] 2;;


(* Multiplication DPR naive *)
let rec polynom_dpr_mult p q =
  match (p,q) with
  |([],[]) -> []
  |(a0::[], _) -> List.map (fun x -> a0 *.x) q
  |(_, b0::[]) -> List.map (fun x -> b0 *.x) p
  |_ ->
  let degp = deg p in
  let degq = deg q in
  let n = if (degp > degq) then degp else degq in
  let m = if (n mod 2 = 0) then (n/2) else (n/2)+1 in
  let (p1,p2) = decomp p m and
      (q1,q2) = decomp q m in

  let p1q2 = polynom_dpr_mult p1 q2 and
      p2q1 = polynom_dpr_mult p2 q1 and
      p1q1 = polynom_dpr_mult p1 q1 and
      p2q2 = polynom_dpr_mult p2 q2 in
  
  let r = (polynom_add p1q2 p2q1) in
  let tmp = polynom_add p2q2 (polynom_offset r m) in (* tmp = P2Q2 + X^m*(P1Q2+Q1P2) *)
  polynom_add tmp (polynom_offset p1q1 (2*m))  (* res = tmp + X^(2m)*P1Q1 *)
;;

let p = [1.;2.;3.];;
let q = [0.;1.;4.;5.];;
polynom_dpr_mult p q;;

(* Algo de multiplication de Karatsuba *)
let rec karatsuba p q =
  match (p,q) with
  |([],[]) -> []
  |(a0::[], _) -> List.map (fun x -> a0 *.x) q
  |(_, b0::[]) -> List.map (fun x -> b0 *.x) p
  |_ ->
  let degp = deg p in
  let degq = deg q in
  let n = if (degp > degq) then degp else degq in
  let m = if (n mod 2 = 0) then (n/2) else (n/2)+1 in
  let (p1,p2) = decomp p m and
      (q1,q2) = decomp q m in

  let r2 = karatsuba (polynom_add p1 p2) (polynom_add q1 q2) and
      r1 = karatsuba p1 q1 and
      r3 = karatsuba p2 q2 in
  
  let tmp = polynom_sub (polynom_sub r2 r1) r3 in
  let tmp2 = polynom_add r3 (polynom_offset tmp m) in
  polynom_add tmp2 (polynom_offset r1 (2*m))  
;;

let p = [1.;2.;3.];;
let q = [0.;1.;4.;5.];;
karatsuba p q;;


let p = [1.;2.;3.; 7.; -23.; 1.];;
let q = [0.;1.;4.;5.; 0.; 0.; 1.];;
karatsuba p q;;
polynom_dpr_mult p q;;
polynom_naive_mult p q;;

(*
let fill_with_zeros p newdeg =
  let rec aux p newdeg k acc =
    match (p, k) with
    |(_,k) when k > newdeg -> acc
    |([],k) when k <= newdeg -> aux [] newdeg (k+1) (0.::acc)
    |(ak::pp, k) -> aux pp newdeg (k+1) (ak::acc)
    |_ -> failwith "pb"
  in
  List.rev(aux p newdeg 0 [])
;;

let p = [1.;1.;1.;1.;1.;2.;4.];;
fill_with_zeros p 2;;


 *)
