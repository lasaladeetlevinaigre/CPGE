#include <stdlib.h>
#include <limits.h>
#include <stdio.h>
#include <assert.h>
#include <stdbool.h>

struct maillon
{
  int donnee;
  struct maillon *suivant;
};
typedef struct maillon maillon_t;

maillon_t *init(void)
{
  maillon_t *m1 = malloc(sizeof(maillon_t));
  assert(m1 != NULL);
  maillon_t *m2 = malloc(sizeof(maillon_t));
  assert(m2 != NULL);
  m1->donnee= INT_MIN;
  m1->suivant = m2;
  m2->donnee = INT_MAX;
  m2->suivant = NULL;
  return m1;
}

void libere(maillon_t **addr_m)
{
  assert(addr_m != NULL);
  
  maillon_t *m = NULL;
  maillon_t *s = NULL;
   
  m = *addr_m;
  while (m != NULL)
  {
    s = m->suivant;
    free(m);
    m = s;
  }
  *addr_m = NULL;
}

maillon_t *localise(maillon_t *t, int v)
{
  assert(t != NULL);
  maillon_t *p = t;
  maillon_t *n = t->suivant;

  int uprim;
  
  while (n->donnee != INT_MAX) // tant que le suivant n'est pas le maillon sentinelle de fin
  {
    
    uprim = n->donnee;

    if (v <= uprim)
      break;
    
    p = n;
    
    assert(n->suivant != NULL);
    n = n->suivant;
    
  }
  
  return p;
}

/*bool insere_errone(maillon_t *t, int v)
{
  maillon_t *p = localise(&t, v);
  maillon_t *n = malloc(sizeof(maillon_t));
  n->suivant = p->suivant;
  n->donnee = v;
  p->suivant = n;
  return true;
}*/

bool insere(maillon_t *t, int v)
{

  // maillon précédent le nouveau maillon à inserer
  maillon_t *p = localise(t, v); // coût de localisation linéaire (recherche séquentielle *)
  if (p->donnee == v)
    return false; // on n'insère pas: pas de doublons dans un ensemble
  
  // nouveau maillon
  maillon_t *n = malloc(sizeof(maillon_t));
  assert(n != NULL); // gestion d'un eventuel probleme d'allocation 

  // côut d'insertion une fois la zone d'insertion localisee constant
  n->donnee = v;
  n->suivant = p->suivant;
  p->suivant = n;
 
  return true;
}

bool supprime(maillon_t *t, int v)
{
  maillon_t *p = localise(t, v); // coût de localisation linéaire (recherche séquentielle *)

  if (p->suivant->donnee == v) // cout de suppression une fois le maillon localisé constant 
  {
    maillon_t *s = p->suivant;
    p->suivant = p->suivant->suivant;
    free(s);
    return true;
  }
  else
    return false;
}

void print(maillon_t *t)
{
  assert(t != NULL); // il y a toujours un premier maillon sentinelle de debut
  
  maillon_t *n = t->suivant;
  assert(n != NULL); // il y a toujours au min un maillon sentinelle de fin
  
  while (n->donnee != INT_MAX)
  {
    printf("%d ", n->donnee);
    n = n->suivant;
  }
  printf("\n");
}


int random_elt_orig(maillon_t *t)
{
  maillon_t *c = t->suivant;
  int ret = c->donnee;
  if (c->donnee == INT_MAX) {
    assert(false);
  }

  int z = 2;

  while ( (c->suivant)->donnee != INT_MAX) {
    c = c->suivant;
    if (random() %z ) {
      ret = c->donnee;
    }
  }

  return ret;
}

int random_elt(maillon_t *t)
{
  maillon_t *c = t->suivant;

  if (c->donnee == INT_MAX) 
    assert(false); // liste vide
  

  // calcul du nombre n d'éléments de l'ensemble
  int n = 0;
  while ( c->donnee != INT_MAX) {
    c = c->suivant;
    n = n + 1;
  }
  printf("Nombre d'éléments de la liste: %d\n", n);
  // pioche uniforme de l'un de ces éléments (indice de 0 à n-1)
  int idx  = random()%n;
  
  c = t->suivant;
  for (int i = 0; i < idx; i++)
    c = c->suivant;

  return c->donnee;
}

int main(void)
{
  srandom(time(NULL));
  maillon_t *t = init();

  insere(t, 4);
  insere(t, 7);
  insere(t, 1);
  insere(t, 2);
  print(t);

  printf("random element = %d\n", random_elt(t));
  printf("random element = %d\n", random_elt(t));
  printf("random element = %d\n", random_elt(t));
  supprime(t, 1);
  print(t);
  supprime(t, 7);
  insere(t, 3);
  print(t);
  supprime(t, 4);
  print(t);
  
  printf("random element = %d\n", random_elt(t));
  libere(&t);
  return 0;
}
