#include <stdio.h>
#include <stdlib.h>

// c'est le même code que celui
// réalisé en cours pour le calcul
// de la représentation binaire,
// mais plus simple: on ne garde que
// le nombre de bits minimal!
// pas besoin de se compliquer avec
// l'affichage des bits dans le bonne ordre
int nombre_bits_minimal(int n)
{
  if (n == 0)
    return 1;
  
  int q = n;
  int nbits = 0;

  
  while (q != 0)
  {
    nbits = nbits + 1;
    q = q / 2;
  }

  return nbits;
}


int main(int argc, char *argv[])
{

  if (argc != 2)
  {
    printf("Erreur sur le  nombre d'arguments d'entrée\n");
    return 1;
  }
    

  int q = atoi(argv[1]);
  int nbits_min = nombre_bits_minimal(q);
  printf("Il faut au minimum %d bits pour encoder la valeur %d\n", nbits_min, q);
  
  return 0;
}
