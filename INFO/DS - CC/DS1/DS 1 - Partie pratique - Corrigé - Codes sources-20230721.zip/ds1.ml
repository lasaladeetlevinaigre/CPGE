let g x = x +. 5.0;;

g 3.0;;
g (-1.2);;

let f x = 5.0 *. x *. x +. 3.0;;

f 4.5;;
f (-1.3);;

let g_rond_f x = g (f x);;

g_rond_f 0.0;;
g_rond_f (-1.0);;

let affiche_parite n =
  if (n mod 2 = 0) then
    Printf.printf "Le nombre %d est pair\n" n
  else
    Printf.printf "Le nombre %d est impair\n" n
;;


affiche_parite 43;;

affiche_parite (-22);;
