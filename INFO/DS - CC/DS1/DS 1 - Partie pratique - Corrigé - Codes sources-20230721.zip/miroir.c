#include <stdlib.h>
#include <stdio.h>

// Pour récupérer les chiffres d'un nombre écrit en base 10
// la boucle est la même que celle du code réalisé en cours
// sauf que l'on ne divise pas par deux mais par 10
int miroir(int n)
{
  int c;
  int q;
  int res;

  q = n;
  res = 0;
  while (q != 0)
  {
    res = res*10;
    c = q % 10; // récupére le chiffre associé à 10 puissance i où i correspond au ieme tour de boucle 
    res += c; 
    q = q / 10;  // on divise par 10 à chaque itération pour changer de chiffre   
  }

  // si le nombre de départ s'écrit c_n... c_3 c_2 c_1 c_0 ou les c sont les
  // chiffres en base 10 du nombre
  // à la fin, res contient  ( (c_0*10* +c_1)*10 + c_2 ) * 10 + c_3 ....)*10 +c_n
  // En développant, on voit bien que:
  // c_0 est multiplié par 10^n
  // c_1 est mutliplie par 10^{n-1]
  // ...
  // c_{n-1} est multiplié par 10
  // c_n est multiplié par rien
  // res contient donc bien la valeur du nombre miroir!
  return res;
  
}

int main(int argc, char *argv[])
{
  if (argc != 2)
  {
    printf("Erreur: nombre d'arguments invalide\n");
    return 1;
  }
  
  int n;
  int n_miroir;
  
  n = atoi(argv[1]);
  if (n < 0)
  {
    printf("Erreur: vous avez donné un nombre négatif\n");
    return 1;
  }
  
  n_miroir = miroir(n);
  printf("Le nombre miroir de %d est %d\n", n, n_miroir);
  
  return 0;
}
