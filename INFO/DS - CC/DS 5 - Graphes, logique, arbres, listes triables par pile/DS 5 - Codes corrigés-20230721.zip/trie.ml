(* https://v2.ocaml.org/api/Option.html *)

(* type 'a option: pour des valeurs de type 'a qui peuvent être definies ou non *)
(* type 'a option = None | Some of 'a *)
(* permet de bien différencier proprement si une valeur optionnelle a bien été définie --> match avec les constructeurs Some/None*)

type 'v trie =
 {
    mutable node_val : 'v option;
    branches : (char, 'v trie) Hashtbl.t
 };;

let trie_create () =
  {
    node_val = None;
    branches = Hashtbl.create 8
  }
;;

let trie_add t k v =
  let rec aux_add t k v i =
    if i = String.length k then
        t.node_val <- Some(v)
    else
      let subt = Hashtbl.find_opt t.branches k.[i] in
      match subt with
      |None -> let st = (trie_create () ) in
               (Hashtbl.add t.branches k.[i] st; aux_add st k v (i+1) )
      |Some(st) -> aux_add st k v (i+1)
  in
  aux_add t k v 0
;;

let t = trie_create ();;
trie_add t "toto" 1;;
trie_add t "toto" 1;;
trie_add t "toto" 1;;
trie_add t "tata" 1;;
trie_add t "tata" 1;;

let trie_print t = 
let rec aux_print k t =
  match t.node_val with
  | None ->  Printf.printf "(k=%c, -) " k; Hashtbl.iter aux_print t.branches;
  | Some(v) -> Printf.printf "(k=%c, v=%d) " k v; Hashtbl.iter aux_print t.branches; 
in
aux_print (' ') t
;;

trie_print t;;
trie_add t "tota" 2;;
trie_print t;;
trie_add t "totol" 3;;
trie_print t;;
trie_add t "total" 4;;
trie_print t;;


let trie_find_opt t k =
  let rec aux_find t k i =
    if (i = String.length k) then
      t.node_val
    else
      let subt = Hashtbl.find_opt t.branches k.[i] in
      match subt with
      | None -> None
      | Some(st) -> aux_find st k (i+1)
in
aux_find t k 0
;;
       
         
trie_find_opt t "total";;
trie_find_opt t "totil";;
trie_find_opt t "toto";;
trie_find_opt t "tot";;



let trie_remove t k =
  let rec aux_remove t k i =
    if (i = String.length k) then
      (if (Hashtbl.length t.branches = 0) then
         Hashtbl.reset t.branches;
       match t.node_val with
       |None ->false
       |Some(_) -> (t.node_val <- None; true)
      )
    else
      let subt = Hashtbl.find_opt t.branches k.[i] in
      match subt with
      | None -> false
      | Some(st) -> aux_remove st k (i+1)
in
aux_remove t k 0
;;


trie_remove t "tutu";;
trie_remove t "toto";;
trie_remove t "toto";;
trie_remove t "total";;
trie_print t;;
trie_find_opt t "tota";;
trie_find_opt t "toto";;
