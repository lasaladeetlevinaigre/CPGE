type arbre =
  | V
  | N of arbre * int * arbre
;;

let rec parcours_prefixe a =
  match a with
  | V -> []
  | N(g,x,d) -> x::(parcours_prefixe g)@(parcours_prefixe d)
;;

let rec aux_etiquette a i =
    match a with
    | V -> (V, i)
    | N(g, _, d) -> let (ng, j) = aux_etiquette g i
                    in let (nd, j2) = aux_etiquette d (j+1) in
                       (N(ng, j, nd), j2)
;;  

let etiquette a =
  let (t, _) = aux_etiquette a 0 in t
;;

let test1_attendu = N(N(N(V, 0, N(V, 1, V)),2, V), 3, N(N(V,4,V),5, N(N(V,6,V),7, V)));;
let test1_desetiquete = N(N(N(V, 7, N(V, 3, V)),4, V), 8, N(N(V,5,V),6, N(N(V,1,V),3, V)));;
etiquette test1_desetiquete;;

let print_list l p res  =
  Printf.printf "\nListe: ";
  List.iter (fun x -> Printf.printf "%d " x) l;
  Printf.printf "\nPile: ";
  List.iter (fun x -> Printf.printf "%d " x) p;
  Printf.printf "\nRes : ";
  List.iter (fun x -> Printf.printf "%d " x) res;
  Printf.printf "\n";
;;
let trier_avec_affichages l =
  let rec aux l pile res =
    print_list l pile res;
    match (l, pile) with
    | ([], []) -> res
    | ([], h::t) -> aux l t (h::res)
    | (h::t, []) -> aux t [h] res
    | (h::t, h1::t1) when h < h1 -> aux t (h::pile) res
    | (_, h1::t1)  -> aux l t1 (h1::res)
  in aux l [] []
;;

let trier l =
  let rec aux l pile res =
    match (l, pile) with
    | ([], []) -> res
    | ([], h::t) -> aux l t (h::res)
    | (h::t, []) -> aux t [h] res
    | (h::t, h1::t1) when h < h1 -> aux t (h::pile) res
    | (_, h1::t1)  -> aux l t1 (h1::res)
  in aux l [] []
;;


(* cas test donné par l'énoncé *)
trier_avec_affichages [3;2;0;1;5;4;7;6];;
trier [3;2;0;1;5;4;7;6];;
(* cas test question 1*)
trier_avec_affichages [4;1;0;3;2;5;7;6];;
trier [4;1;0;3;2;5;7;6];;
