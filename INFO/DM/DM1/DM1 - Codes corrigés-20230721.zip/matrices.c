#include <stdio.h>
#include <stdlib.h>
#include <assert.h>


void allouer_matrice(int n, int m, int **mat)
{
  // allocation dynamique de la matrice sous la forme
  // d'un tableau unidimensionnel
  // on met toutes les valeurs à 0 grâce à calloc
  *mat = (int *)calloc( n*m, sizeof(int) );

  return;
}

void remplir_matrice(int n, int m, int *mat)
{
  unsigned int i,j;
  
  // boucle sur les lignes
  for (i = 0; i < n; i++)
  {
    // on ne remplit que les valeurs au-dessus de la diagonale car les autres ont déjà été mises à 0 
    for (j = i; j < m; j++) // j indice de colonne
      mat[i*m+j] = i + j;
    
  }

  return;
}

void affiche_matrice(int *mat, int nlignes, int ncolonnes)
{
  // on verifie que la matrice a bien ete allouee
  assert(mat != NULL); // programmation défensive
  
  unsigned int i, j;
  
  for (i = 0; i < nlignes; i++) // on parcourt toutes les lignes 
  {
    for (j = 0; j < ncolonnes; j++) // on parcourt toutes les cases du tableau tles colonnes
      printf("%3d ", mat[i*ncolonnes +j]); // on affiche la valeur d'indices (i, j)
    printf("\n"); // on retourne à la ligne à la fin de chaque ligne
  }
  
  printf("\n");
  
  return;
}

int main(int argc, char **argv)
{
  // on vérifie que l'utilisateur a au moins donné une entrée
  // (au moins 2 mots sur la ligne de commande)
  assert(argc == 3);

  int *mat = NULL;

  int  n = atoi(argv[1]); // récupération du nombre de lignes
  int  m = atoi(argv[2]); // récupération du nombre colonnes

  // prog défensive
  assert(n > 0);
  assert(m > 0);

  // passage par adresse du pointeur mat pour qu'il soit rempli avec l'adresse du nouvel espace alloué dans la fonction allouer_matrice
  allouer_matrice(n, m, &mat);

  remplir_matrice(n, m, mat);
  

  // affichage de la matrice
  printf("Matrice calculée de taille %d par %d:\n", n, m);
  affiche_matrice(mat, n, m);

  // libération de l'espace mémoire avant sortie du code
  // programmation défensive, on verifie bien que l'adresse
  // pointe vers un espace mémoire avant de désallouer cet espace
  if (mat == NULL) 
    free(mat);
  
  mat = NULL; // programmation défensive: par sécurité pour que l'adresse stockée dans mat ne soit pas réutilisée à mauvais escient, on la remet à NULL
  
  return 0;
}
