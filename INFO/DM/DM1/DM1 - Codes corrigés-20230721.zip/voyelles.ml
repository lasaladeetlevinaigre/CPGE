(* Fonction permettant de savoir si un caractere est ou non une voyelle *)
(* @param c: un caractere donne en entree *)
(* @return: une valeur booleenne vraie si le caractere c est une voyelle, fausse sinon
 *)
let est_voyelle c = 
   if (c = 'a' || c = 'e' || c = 'i' ||
         c = 'o' || c = 'u' || c = 'y' ) then
     true
   else
     false
;;

(* Tests*)
est_voyelle 'p';;
est_voyelle 'o';;
est_voyelle 'z';;


(* Fonction permettant de savoir si un caractere est ou non une voyellecompter le nombre de caracteres dans un texte *)
(* @param texte: le texte à analyser *)
(* @return: le nombre de voyelles dans le texte
 *)
let compte_voyelles texte =
  let n_voy = ref 0 in (* le nombre de voyelles évolue donc il faut utiliser une référence *)
  for i = 0 to (String.length texte) - 1 do
    let c = texte.[i] in
    if (est_voyelle c = true) then
         n_voy := !n_voy+1
  done;
  !n_voy;;


compte_voyelles "je suis beau";;
compte_voyelles "capitaine flamme tu n'es pas de notre galaxie";;
(* Une phrase qui permet de connaître la ligne 3 du tableaux des éléments chimiques de Mendeleiev Na Mg Al Si P S Cl Ar *)
compte_voyelles "napoleon a mange allegrement six poulets sans claquer d'argent";;

