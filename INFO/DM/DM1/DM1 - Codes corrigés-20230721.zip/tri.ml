(* Fonction permettant de trier un tableau dans l'ordre croissant de ses valeurs. Le tableau est trie "en place", aucun nouvel espace mémoire n'est alloué *)
(* @param tab: tableau à trier *)
(* @return tableau trie *)
let tri_a_bulles tab =
  let n = Array.length tab in
  let echanges = ref true in
  while !echanges = true do
    echanges := false;
    for i = 0 to n-2 do
      if tab.(i) > tab.(i+1) then
      (
        let buf = tab.(i) in
        (
          tab.(i) <- tab.(i+1);
          tab.(i+1) <- buf;
          echanges := true
        )
      )
    done;
  done;
  tab;;

(* Tests sur differents tableaux *)
let tab1 = [| -5; 2; 3; 7; -1|] in tri_a_bulles tab1;;
let tab2 = [| -5.1; 2.3; -1.7; 5.34; -1.0|] in tri_a_bulles tab2;;
let tab3 = [| 'a'; 'h'; 'c'; 'g'; 'b'; 'e'; 'f'; 'd'|] in tri_a_bulles tab3;;

(* REMARQUE: Notre fonction tri_a_bulles est polymorphe: 
elle peut traiter des tableaux de n'importe quel type *)
(* val tri_a_bulles : 'a array -> 'a array = <fun> *)
