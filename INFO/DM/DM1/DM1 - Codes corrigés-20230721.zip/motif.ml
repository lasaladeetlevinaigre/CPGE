let repere_motif texte motif =
  
  let n = String.length texte in
  let m = String.length motif in
  let nhits = ref 0 in (* compteur d'occurrences *)
  
  for i = 0 to n-1 do

    (* si le premier caractere du motif est egal à la lettre courante dans letexte *)
    if (texte.[i] = motif.[0]) then

      (* on analyse la suite pour voir si tout le motif est retrouvé dans le texte *)
      let hit = ref true in
      let j = ref 1 in (* indice de déplacement dans la chaine du motif *)

      (* Tant que les indices des deux chaines ne depassent pas la taille
         des chaines et que le motif et la chaine correspondent, on continue
         à verifier 
         La boucle s'arrête quand on a atteint la fin du texte ou du motif ou
         quand on a repéré une différence entre les deux chaines *)
      while ( (!j < m) && (i + (!j) < n) && (!hit = true)) do
        
        (if (texte.[i+(!j)] <> motif.[!j]) then
          hit := false);
        (*Printf.printf "%d %c %d %c\n" (i+(!j)) texte.[i+(!j)] (!j) motif.[!j];*)
        j := (!j)+1
      done;

      (* si la valeur referencee par hit est true, alors on a trouvé une correspondance totale et on augmente de 1 (on incrémente) le nombre d'occurrences *)
      if (!hit = true) then
        nhits := !nhits + 1;

  done;
  !nhits (* la valeur retour est cette derniere evaluation, cad le nombre total d'occurrences du motif dans le texte *)
;;
    
let nombre_occurrences = repere_motif "l'arrivee des riverains pres de la riviere" "riv" in
    Printf.printf "Il y %d occurrences du motif dans le texte\n" nombre_occurrences;;

let nombre_occurrences = repere_motif "ma maman m'amadoue" "ama" in
    Printf.printf "Il y %d occurrences du motif dans le texte\n" nombre_occurrences;;

let nombre_occurrences = repere_motif "coucou les zouzous choupinous" "ou" in
    Printf.printf "Il y %d occurrences du motif dans le texte\n" nombre_occurrences;;

let nombre_occurrences = repere_motif "il n'y a pas d'helice helas, c'est la qu'est l'os (La Grande Vadrouille)" "hel" in
    Printf.printf "Il y %d occurrences du motif dans le texte\n" nombre_occurrences;;

let nombre_occurrences = repere_motif "il n'y a pas d'helice helas, c'est la qu'est l'os (La Grande Vadrouille)" "hel" in
    Printf.printf "Il y %d occurrences du motif dans le texte\n" nombre_occurrences;;
