#include <stdio.h>
#include <stdbool.h>
#include <assert.h>
#include <string.h> // pour la fonction strlen

// repere_motif
// @param texte: la chaine de caractères dans laquelle  on cherche le motif
// @param motif: la chaine de caractères qui correspond au motif
// @param premier: l'adresse d'un pointeur que l'on va faire pointer vers la
//                 1ere occurrence du motif. Le pointeur est passé PAR ADRESSE //                ce qui explique l'usage du pointeur de pointeur
//@return: le nombre d'occurrences du motif dans le texte
int repere_motif(char *texte, char *motif, char **premier)
{
  // programmation défensive: on s'assure que les pointeurs pointent
  // bien vers quelque chose... sinon nous aurons une erreur de segmentation
  // ou d'horribles bugs très durs à corriger
  assert(texte != NULL);
  assert(motif != NULL);
  assert(premier != NULL);

  unsigned int i, j;
  bool hit;
  unsigned int nhit;
  unsigned int n = strlen(texte);
  unsigned int m = strlen(motif);
  
  nhit = 0;
  *premier = NULL;
  for (i = 0; i < n; i++)
  {
    // Si la lettre du texte correspond à la premiere lettre du motif
    if (texte[i] == motif[0]) 
    {     
     // on parcourt en même temps le motif et le texte
     // à partir de cette lettre
     hit = true;
     j = 1;
     while(j < m && i+j < n && hit == true)
     {
       if (motif[j] != texte[i+j])  // des qu'il y a une différence
	 hit = false; // le booléen hit est remis à false
                      // pour indiquer qu'il n'y a pas correspondance
	              // de motif
       j = j + 1;
     }
     // si hit est resté à true, cela veut dire que tout le motif a
     // été retrouvé dans le texte
     if (hit == true)
     {
       // si la 1ere occurence n'a pas déjà été renseignée
       if (*premier == NULL) 
	 *premier = &(texte[i]); // on affecte l'adresse du début de la premiere occurrence au pointeur (premier est l'adresse du pointeur)

       nhit = nhit + 1;
     }
    }
  }

  return nhit;
}

int main(int argc, char **argv)
{
  // programmation défensive: on vérifie que l'utilisateur a bien
  // donné 2 chaines de caractères (texte et motif) donc qu'il y a
  // bien 3 mots sur la ligne de commande
  assert(argc == 3);

  char *texte = argv[1];
  char *motif = argv[2];

  char *premiere_occurrence = NULL; 
  int   n;
  
  // appel de la fonction. récupération du nombre d'occurrences du
  // motif dans une variable n. Mise a jour par la fonction du pointeur
  // premiere_occurrence grace au passage par adresse
  n = repere_motif(texte, motif, &premiere_occurrence);

  // affichage des résultats
  printf("Le motif %s a été repéré %d fois dans le texte:\n\"%s\"\n", motif, n, texte);
  printf("Première occurence: %s\n", premiere_occurrence);
  
  return 0;
}
