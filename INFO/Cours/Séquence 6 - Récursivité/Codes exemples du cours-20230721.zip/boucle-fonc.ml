let boucle_imperative x0 =
  let x = ref x0 in
  while ( !x <= 42 ) do
    x := !x + 3
  done;
!x;;

boucle_imperative 19;;

let rec boucle_fonctionnelle x0 =
  match x0 with
  | x when x <= 42 -> boucle_fonctionnelle (x+3)
  | _ -> x0
;;

boucle_fonctionnelle 19;;



let double_loop_imp x0 =
  let x = ref x0 in
  for i = 1 to 4 do
    for j = 1 to 4 do
      x := !x *i + j
    done
  done;
  !x
;;

double_loop_imp 0;;


let double_loop_fonc x0 =
  let rec loop_int y i0 j=
    match j with
    |j when j <= 4 -> (Printf.printf "loop_int %d %d %d\n" (y*i0 + j) i0 (j+1); loop_int (y*i0 + j) i0 (j+1))
    |_  -> y
  in
  let rec loop_ext x i=
    match i with
    | i when i <= 4 -> (Printf.printf "loop_ext (loop_int %d %d 1) (%d)\n" x i (i+1) ; loop_ext  (loop_int x i 1) (i+1)) 
    | _ -> x
  in
  loop_ext x0 1
;;

let double_loop_fonc x0 =
  let rec loop_int y i0 j=
    match j with
    |j when j <= 4 -> loop_int (y*i0 + j) i0 (j+1)
    |_  -> y
  in
  let rec loop_ext x i=
    match i with
    | i when i <= 4 -> loop_ext  (loop_int x i 1) (i+1) 
    | _ -> x
  in
  loop_ext x0 1
;;

double_loop_fonc 0;;
