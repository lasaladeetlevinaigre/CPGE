let mult x0 y0 =
  
  let p = ref 0
  and x = ref x0
  and y = ref y0 in
  
  while !x > 0 do
    if !x mod 2 = 1 then
      p := !p + !y;
    x := !x / 2;
    y := !y * 2;
  done;
  !p
;;

mult 3 6;;
mult 8 11;;

let rec mult2 x y =
  if (x = 0) then
    0
  else
    if (x mod 2 = 0) then
      mult2 (x/2) (2*y)
    else
      mult2 (x/2) (2*y) + y
;;

mult2 3 6;;
mult2 8 11;;

let rec mult3 x y =
  if (x = 0) then
    0
  else
    mult3 (x/2) (2*y) + y*(x mod 2)
;;

mult3 3 6;;
mult3 8 11;;

let rec mult4 x y =
  match x with
  | 0 -> 0
  | _ -> mult4 (x/2) (2*y) + y*(x mod 2)
;;

mult4 3 6;;
mult4 8 11;;

let mult5 x y =
  let rec aux acc x y =
    match x with
    | 0 -> acc
    | _ -> aux (acc + y*(x mod 2)) (x/2) (y*2)
  in aux 0 x y
;;

mult5 3 6;;
mult5 8 11;;
