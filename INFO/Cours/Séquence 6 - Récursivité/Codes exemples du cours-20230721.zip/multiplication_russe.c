#include <stdio.h>
#include <assert.h>
#include <stdlib.h>

int mult(unsigned int x0, unsigned int y0)
{
  unsigned int p = 0;
  unsigned int x = x0;
  unsigned int y = y0;

  while (x > 0)
  {
    if (x % 2 == 1)
      p = p + y;
    x = x / 2; // division euclidienne entiere
    y = y * 2;
  }

  return p;
}

int mult2(unsigned int x, unsigned int y)
{
  if (x == 0)
    return 0;

  if (x % 2 == 0 )
    return mult2( x/2, y*2 );
  else
    return ( mult2( x/2, y*2 ) + y );
}

int mult3(unsigned int x, unsigned int y)
{
  if (x == 0)
    return 0;

  return ( mult3( x/2, y*2 ) + y * (x % 2) );
  
}

int mult4(unsigned int x, unsigned int y)
{
  switch(x)
  {
    case 0:
      return 0;
      
    default:
      return mult4( x/2, y*2 ) + y * (x % 2);
  }
}


int aux(unsigned int acc, unsigned int x, unsigned int y)
{
  switch(x)
  {
    case 0:
      return acc;
      
    default:
      return aux(acc + y * (x%2), x/2, y*2);
  }
}

int mult5(unsigned int x, unsigned int y)
{
  return aux(0, x, y);
}
  
int main(int argc, char **argv)
{
  assert(argc == 3);

  int x = atoi(argv[1]);
  assert(x >= 0);
    
  int y = atoi(argv[2]);
  assert(y >= 0);
    
  printf("mult  %d * %d = %d\n", x, y, mult(x,y) );
  printf("mult2 %d * %d = %d\n", x, y, mult2(x,y) );
  printf("mult3 %d * %d = %d\n", x, y, mult3(x,y) );
  printf("mult4 %d * %d = %d\n", x, y, mult4(x,y) );
  printf("mult5 %d * %d = %d\n", x, y, mult5(x,y) );
  
  return 0;
}
