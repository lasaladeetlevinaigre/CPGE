#include <stdio.h>
#include <stdbool.h>
#include <assert.h>
#include <limits.h> 
#include <stdlib.h> // pour atoi et pour rand
#include <time.h>

/************************************************************************
   UTILITAIRES  TABLEAUX 
************************************************************************/
void affiche_tableau(int *tab, unsigned int n)
{
  assert(tab != NULL);
  assert(n > 0);

  unsigned int i;
  
  for (i = 0; i < n; i++)
    printf("%d ", tab[i]);
  printf("\n");

  return;
}

void swap(int *a, int *b)
{
  int buf = *a;
  *a = *b;
  *b = buf;
  return;
}

int *genere_tab_aleatoire(int n, int a, int b)
{
  int i;
  int *tab = NULL;
  double d;
  
  assert(n > 0);

  tab = malloc(n*sizeof(int));

  assert(tab != NULL);

  // Tolérance du coup si a > b: on les échange!
  if (a > b)
    swap(&a, &b);


  for (i = 0; i < n; i++)
  {
    d = (double)(  rand()  / (double)RAND_MAX )*(b-a+1);

    tab[i] = a + (int)d;
  }
  
  return tab;
}



/************************************************************************
   ALGORITHMES DE TRI
************************************************************************/


void tri_a_bulles(int *tab, int n)
{
  unsigned int i; // variable de compteur de boucle
  bool il_y_a_encore_des_echanges; // booleen indiquant s'il y a encore des échanges réalisés

  assert(tab != NULL); // on s'assure que le pointeur tab pointe bien vers qqch
  
  il_y_a_encore_des_echanges = true;

  // tant que des échanges ont encore lieu
  while (il_y_a_encore_des_echanges == true)
  {
    il_y_a_encore_des_echanges = false;
    for (i = 0; i < n-1; i=i+1) // attention, on ne va que jusqu'à n-1!
    {
      if (tab[i] > tab[i+1]) // si les deux éléments sont inversés
      {
	swap(&(tab[i]), &(tab[i+1])); // on les échange
	il_y_a_encore_des_echanges = true; // on note qu'il y a encore eu des échanges: a priori, on va devoir refaire un tour de tableau
      }
    }
  }

  return;
}


/************************************************************************
   ALGORITHMES DE RECHERCHE
************************************************************************/

int seq_search(int v, int *t, unsigned int n)
{
  assert(t != NULL);
  
  unsigned int idx = 0;
  
  while (idx < n && t[idx] != v)
    idx = idx + 1;
  
  if (idx == n) // si idx == n, on n'a pas trouvé la valeur
    idx = -1;
  
  return idx;
}

int bin_search(int v, int *t, unsigned int n)
{
  assert(t != NULL);

  unsigned int l =  0;
  unsigned int r = n-1;
  unsigned int m;
  int val_mid;
  
  while (r >= l)
  {
    m = ( r + l )/2; // c'est uen division euclidienne
    val_mid = t[m];
   
    if (val_mid == v) // valeur trouvée!
      return m;
    

    if (v < val_mid) // la valeur recherchée est donc dans la partie gauche du tableau
      r = m - 1;
    else // sinon elle est dans la partie droite
      l = m + 1;
  }

  // si on arrive ici, c'est qu'on n'a pas trouvé la valeur recherchée
  return -1;
}

int aux_bin_search_rec(int v, int *t, unsigned int l, unsigned int r)
{
  assert(t != NULL);

  unsigned int m;
  int val_mid;

  if (r < l) // CAS TERMINAL: pas de valeur trouvée
    return -1;


  m = (r+l)/2;
  val_mid = t[m];
   
  if (val_mid == v) // CAS TERMINAL: valeur trouvée!
    return m;
  
  if (val_mid > v) // la valeur recherchée est donc dans la partie gauche du tableau
    return aux_bin_search_rec(v, t, l, m-1);
  else // sinon elle est dans la partie droite
    return aux_bin_search_rec(v, t, m+1, r);
}

int bin_search_rec(int v, int *t, unsigned int n)
{
  return aux_bin_search_rec(v, t, 0, n-1);
}


int main(int argc, char *argv[])
{
  // on initialise le générateur de nombres pseudo-aléatoires
  srand(time(NULL));
  
  assert(argc == 2);

  int taille = atoi(argv[1]);

  assert(taille > 0);

  unsigned int n = (unsigned int)taille;

  int *tab = genere_tab_aleatoire(n, 0, 1000);
  affiche_tableau(tab, n);
  
  
  // tri du tableau
  tri_a_bulles(tab, n);
  affiche_tableau(tab, n);

  // recherche de la valeur val dans le tableau
  int val = tab[3];//rand()%100;
  
  int idx_loc;

  idx_loc = seq_search(val, tab, n);
  if (idx_loc != -1)
    printf("Recherche séquentielle: valeur %d trouvée, indice %d\n", val, idx_loc);
  
  idx_loc = bin_search(val, tab, n);
  if (idx_loc != -1)
    printf("Recherche dichotomique impérative: valeur %d trouvée, indice %d\n", val, idx_loc);


  idx_loc = bin_search_rec(val, tab, n);
  if (idx_loc != -1)
    printf("Recherche dichotomique récursive: valeur %d trouvée, indice %d\n", val, idx_loc);

  
  if (tab != NULL)
    free(tab);
  tab = NULL;
  
  return 0;
}
