let rec hanoi ndisques tige_depart tige_interm tige_arrivee =
  if ndisques = 1 then
    Printf.printf "Tige %d --> Tige %d\n" tige_depart tige_arrivee
  else
    (
      hanoi (ndisques-1) tige_depart tige_arrivee tige_interm;
      hanoi 1            tige_depart tige_interm tige_arrivee;
      hanoi (ndisques-1) tige_interm tige_depart tige_arrivee
    )
;;

hanoi 3 1 2 3;;
