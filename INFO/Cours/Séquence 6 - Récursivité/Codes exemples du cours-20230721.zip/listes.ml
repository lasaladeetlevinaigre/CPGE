let l1 = [3; -5; 7; 21; -8];;

let l2 = ['f'; 'a'; 'c'; '1'; 'l'];;

let l3 = [ (3.1, 'x'); (2.9, 'z'); (-1.77, 'b')];;

let l4 = [ [1;4;2] ; [-1;-2] ; [6;7;8;9;11] ];;


let l1 = [ 3; -5; 7; 21; -8 ];;
let t1 = [|3; -5; 7; 21; -8|];;


let a = -3;;
let l = [5 ; -7 ; 21];;
let new_l = a ::l;;

let a = 2.5;;
let l = [5 ; -7 ; 21];;
let new_l = a ::l;;

let l1 = [ 3; -5; 7; 21; -8 ];;
let tete::queue = l1;;

let rec est_dans_la_liste valeur l =
  match l with
  | [] -> false (* cas terminal où l est la liste vide *)
  | tete::queue -> if (tete = valeur) then                (* on regarde si la valeur est celle de la tête de liste *)
                     true
                   else 
                     (est_dans_la_liste valeur queue)     (* appel recursif sur le reste de la liste*)
;;

let l1 = [ 3; -5; 7; 21; -8 ];;
est_dans_la_liste   21 l1;;
est_dans_la_liste (-2) l1;;

let affiche_element v = Printf.printf "elt=%d " v;;
List.iter affiche_element l1;;