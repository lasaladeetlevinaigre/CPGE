let affichage_personnalise v = Printf.printf "Valeur: %f\n" v;;
let l1 = [1.5; 2.0; 2.3; 2.7];;  
List.iter affichage_personnalise l1;;

let l1 = [1.5; 2.0; 2.3; 2.7];;  
let mult_par_5 x = 5.0 *. x;;
let l2 = List.map mult_par_5 l1;;
          

let plus_grand_strict_que_2 y = (y > 2.0);;

List.for_all plus_grand_strict_que_2 l1;;
List.for_all plus_grand_strict_que_2 l2;;


let f compteur x =
  if (x > 0.) then
    (
      compteur := !compteur+1;
      compteur
    )
  else
    compteur
;;
let l = [1.5; -2.0; 2.3; -2.7; 1.3];;  
List.fold_left f (ref 0) l;;
