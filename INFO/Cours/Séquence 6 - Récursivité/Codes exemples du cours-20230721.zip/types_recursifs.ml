type liste_de_caracteres =
  Vide
| Concat of char * liste_de_caracteres
;;

let chaine_vide = Vide;;
let chaine = Concat('u', chaine_vide);;
let chaine2 = Concat('o', chaine);;
let chaine3 = Concat('L', chaine2);;
