let seq_search valeur tab =
  let idx = ref 0 in
  let n = Array.length tab in
  while (!idx < n && tab.(!idx) <> valeur)
  do
    idx := !idx + 1
  done;
  if (!idx = n) then
    idx := -1;
  !idx
;;


let tab = [| -5; 2; 3; 7; -1|] in seq_search 7 tab;;
let tab = [| -5; 2; 3; 7; -1|] in seq_search 11 tab;;




(* Fonction permettant de trier un tableau dans l'ordre croissant de ses valeurs. Le tableau est trie "en place", aucun nouvel espace mémoire n'est alloué *)
(* @param tab: tableau à trier *)
(* @return tableau trie *)
let tri_a_bulles tab =
  let n = Array.length tab in
  let echanges = ref true in
  while !echanges = true do
    echanges := false;
    for i = 0 to n-2 do
      if tab.(i) > tab.(i+1) then
      (
        let buf = tab.(i) in
        ( tab.(i) <- tab.(i+1); tab.(i+1) <- buf; echanges := true )
      )
    done;
  done;
  tab;;

(* Tests sur differents tableaux *)
let tab1 = [| -5; 2; 3; 7; -1|] in tri_a_bulles tab1;;
let tab2 = [| -5.1; 2.3; -1.7; 5.34; -1.0|] in tri_a_bulles tab2;;
let tab3 = [| 'a'; 'h'; 'c'; 'g'; 'b'; 'e'; 'f'; 'd'|] in tri_a_bulles tab3;;

(* REMARQUE: Notre fonction tri_a_bulles est polymorphe: 
elle peut traiter des tableaux de n'importe quel type *)
(* val tri_a_bulles : 'a array -> 'a array = <fun> *)


let bin_search v t =
  
  let l = ref 0 and
      r = ref ( (Array.length t) - 1 ) and
      found   = ref false and
      idx_loc = ref (-1) in
      
  while (r >= l && !found = false) do
    
    let m = ((!r) + (!l) )/2 in
    let val_mid = t.(m) in

    if (val_mid = v) then
      (
        found := true;        
        idx_loc := m        
      )
    else
      (
        if (val_mid > v) then
          r := m - 1
        else
          l := m + 1
      )             
  done;
  !idx_loc
;;

let t1 = tri_a_bulles [| -5; 2; 3; 7; -1|];;
bin_search (-1) t1;;



let bin_search_rec v t =
  let rec aux v t l r =
    match (l, r) with
    | (l, r) when r < l -> -1
    | _ -> let m = (l+r)/2 in
           match t.(m) with
           | val_mid when val_mid = v -> m
           | val_mid when v < val_mid -> aux v t l (m-1)
           | _ -> aux v t (m+1) r
  in
  let n = Array.length t in
  aux v t 0 (n-1)
;;


let t2 = tri_a_bulles [| -5; 2; 3; 7; -1; 53; 42; -8|];;
bin_search_rec 7 t2;;
bin_search_rec 11 t2;;

let bin_search_rec3 v t  =
let rec aux_bin_search3 v t l r =
  
  if (r < l) then
       -1
  else
    (
      let m = (r + l)/2 in
      let val_mid = t.(m) in
      match val_mid with
      | y when y = v -> m
      | y when y > v -> aux_bin_search3 v t l (m-1)
      |_                  -> aux_bin_search3 v t (m+1) r
    )
in
let n = Array.length t in
aux_bin_search3 v t 0 (n-1) 
;;

let t2 = tri_a_bulles [| -5; 2; 3; 7; -1; 53; 42; -8|];;
bin_search3 7 t2;;


