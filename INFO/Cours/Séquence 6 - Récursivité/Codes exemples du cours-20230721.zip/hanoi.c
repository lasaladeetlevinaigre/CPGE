#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

void hanoi(unsigned int ndisques, short int tige_depart,  short int tige_interm, short int tige_arrivee)
{

  if (ndisques == 1) // cas terminal
  {
    printf("Tige %d ---> Tige %d\n", tige_depart, tige_arrivee);
    return;
  }

  // on deplace n-1 disque vers la tige intermédiaire
  hanoi(ndisques-1, tige_depart, tige_arrivee, tige_interm);
  // on déplace le gros disque du dessous vers la tige d'arrivée
  hanoi(1, tige_depart, tige_interm, tige_arrivee);
  // on redéplace les n-1 disques de la tige intermédiaire vers la tige d'arrivée
  hanoi(ndisques-1, tige_interm, tige_depart, tige_arrivee);

  return;
}

int main(int argc, char **argv)
{

  assert(argc == 2);
  int nombre_de_disques = atoi(argv[1]);

  assert(nombre_de_disques >= 1);

  hanoi(nombre_de_disques, 1, 2, 3);
  
  return 0;
}
