#include <stdio.h>
#include <stdlib.h>

char get_char(int val)
{
  if (val == 0)
    return '0';
  else if (val == 1)
    return '1';
  else if (val == 2)
    return '2';
  else if (val == 3)
    return '3';
  else if (val == 4)
    return '4';
  else if (val == 5)
    return '5';
  else if (val == 6)
    return '6';
  else if (val == 7)
    return '7';
  else if (val == 8)
    return '8';
  else if (val == 9)
    return '9';
  else if (val == 10)
    return 'A';
  else if (val == 11)
    return 'B';
  else if (val == 12)
    return 'C';
  else if (val == 13)
    return 'D';
  else if (val == 14)
    return 'E';
  else if (val == 15)
    return 'F';
  else
  {
    printf("Probleme: Base <= 16 et valeur %d\n", val);
    return 'X';
  }	   
}
void dec_to_baseb(int n, int b)
{
  char c;
  char chiffres[32];
  int  s, q;
  int  n_chiffres = 0;
  int  i;

  if (b > 16)
    return;
  
  

  for (i = 0; i < 32; i++)
    chiffres[i] = '0';

  q = n;
  while (q != 0)
  {
    s = q % b;;
    c = get_char(s); // il faut convertir la valeur en symbole (char) pour les bases plus grandes que 10 notamment
    if (n_chiffres > 31)
    {
      printf("Erreur: l'entier %d ne tient pas sur 32 bits!\n", n);
      return;
    }
    chiffres[n_chiffres] = c;
    q = q / b;
    n_chiffres ++;
  }

  printf("La représentation en base %d de %d est ", b, n);
  for (i = n_chiffres-1; i >= 0; i--)
    printf("%c", chiffres[i]); // on affiche un symbole (char) et non un entier
  printf("\n");
  
}


void dec_to_bin(int n)
{
  int  bits[32];
  int  q;
  int  n_bits = 0;
  int  i;

  if (n == 0 || n ==1 )
  {
    printf("La représentation binaire de %d est %d\n", n, n);
    return;
  }

  // on initialise le tableau avec toutes les cases à 0
  for (i = 0; i < 32; i++)
    bits[i] = 0;

  q = n;
  while (q != 0)
  {
    if (n_bits > 31)
    {
      printf("Erreur: l'entier %d ne tient pas sur 32 bits!\n", n);
      return;
    }
    bits[n_bits] = q % 2;
    q = q / 2;
    n_bits ++;
  }

  // affichage des bits dans le bon ordre:
  //le bit de poids fort doit être le plus à gauche
  // donc on utilise une boucle qui part du bout du tableau et revient vers 0
  printf("La représentation binaire de %d est ", n);
  for (i = n_bits-1; i >= 0; i--)
    printf("%d", bits[i]);
  printf("\n");
  
}

int main(int argc, char *argv[])
{
  if (argc != 2)
  {
    printf("Erreur: nombre d'arguments invalide\n");
    return 1;
  }

  int n = atoi(argv[1]);
  if (n < 0)
  {
    printf("Erreur: vous avez donné un nombre négatif!\n");
    return 1;
  }

  // conversion en binaire
  dec_to_baseb(n, 2);

  // pour vérification, on doit toujours avoir le meme resultat
  // avec l'ancienne fonction de conversion binaire et la nouvelle
  // fonction plus générale
  //dec_to_bin(n); 
  
  // conversion en octal
  dec_to_baseb(n, 8);
  // conversion en hexadecimal
  dec_to_baseb(n, 16);
  return 0;
}
