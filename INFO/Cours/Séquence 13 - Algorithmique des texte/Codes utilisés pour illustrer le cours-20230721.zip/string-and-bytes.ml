
let s = "danger";;
s.[0] <- 'm';; (* Syntaxe obsolete: les string sont immuables en OCaml: elles ne peuvent être modifiées en place *)
s;;

let s = "danger";;
let s2 = s^"osite";; (* les string sont immuables: l'opérateur de concaténation de modifie pas directement s, mais renvoie une nouvelle chaine qui correspond a la concatenation *)
s;;

(* string --> OK pour travailler sur des chaines de caractères immuables *)

(* on peut tricher en utilisant des ref, mais ce n'est pas très satisfaisant, car il  a des duplication mémoire! et aussi un cout linéaire au niveau de la complexité temporelle en fonction du nombre de caractère de la premiere chaine *)
let refs = ref "danger";;
refs := !refs^"osite";;
!refs;;

(* initialisation d'une structure de type bytes (chaine de carcctères mutable *) 
let b = Bytes.of_string "danger";;
Bytes.set b 0 'm';; (* modification du premier caractère (position 0) de la chaîne *)
b;;
let s = Bytes.to_string b;; (* reconversion en type string immuable *)



(* Module Buffer: manipulation de chaînes de caractères de taille varible, par exemple pour subissant des concaténations, des ajours de caractères, en cout amorti constant ==> car implémentation concrète réalisée à l'aide de tableaux redimensionnables *)

let buf = Buffer.create 10;;
Buffer.add_string buf "danger";;
let s = Buffer.contents buf;; (* recupere le contenu du tableau redimensionnable d'octet et le transforme en string immuable *)

Buffer.add_string buf "osite";; (* ajoute une autre chaine de caractere a la fin du tableau redimensionnable ==> concaténation *)
Buffer.contents buf;;

Buffer.add_char buf 's';; (* ajoute un seul caractere en fin de tableau, append, concatenation d'un seul caractere *)
Buffer.contents buf;;
