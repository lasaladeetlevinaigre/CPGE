#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>
#include <assert.h>
#include <stdbool.h>



int *generate_random_array(unsigned int n, int a, int b)
{
  int *tab = malloc(n*sizeof(int));
  assert(tab != NULL); // check allocation ok

  for (int i = 0; i < n; i++)
    tab[i] = a + rand() % (b+1-a);
  
  return tab;
}

void print_array(int *t, int size)
{

  assert(t != NULL);
  
  for (int i = 0; i < size; i++)
    printf("%d ", t[i]);
  
  printf("\n"); 
  
  return;
}

void copy_array(int *copy, int *orig, int l, int r)
{
  assert(orig != NULL);
  assert(copy != NULL);

  assert(l >= 0);
  assert(r > l);
  
  for (int i = l; i < r; i++)
    copy[i] = orig[i];
  
  return;
}

// l = indice gauche large de la fenetre de travail
// r = indice droit strict de la fenetre de travail
// m = indice de découpage milieu de la fenetre [l, r[
// cette fonction fusionne les deux segments triés [l, m[ et [m, r[
// du tableau tab et range le résultat de cette fusion dans le segment
// [l, r[ de res
void merge(int *res, int *tab, int l, int m, int r)
{
  // préconditions
  assert(l >= 0); assert(l <= m); assert(m <= r);
  assert(tab != NULL); assert(res != NULL);

  int k;
  int idx1 = l; // indice d'avancée dans la partie gauche [l, m]
  int idx2 = m; // indice d'avancée dans la partie droite [m+1, r[
  
  for (k = l; k < r; k++)
  {
    // insertion d'un élément de [l,m] dans res
    if ( (idx1 < m) && (idx2 < r ) && (tab[idx1] <= tab[idx2]) )
    {
      res[k] = tab[idx1];
      idx1 = idx1+1;
    }
    // insertion d'un élément de [m+1,r[ dans res
    else if ( (idx1 < m) && (idx2 < r ) && (tab[idx2] < tab[idx1]) )
    {
      res[k] = tab[idx2];
      idx2 = idx2+1;
    }
    // il n'y a plus d'éléments à merger issus du segment [m+1, r[
    else if ( (idx1 < m) && (idx2 >= r) )
    {
      res[k] = tab[idx1];
      idx1 = idx1 + 1;
    }
     // il n'y a plus d'éléments à merger issus du segment [l, m]
    else if ( (idx1 >= m) && (idx2 < r) )
    {
      res[k] = tab[idx2];
      idx2 = idx2 + 1;
    }
    else
    {
      printf("Erreur k=%d idx1=%d idx2=%d l=%d r=%d m=%d\n", k, idx1, idx2, l, r, m);
      return;
    }
  }
  return;
}

// la borne droite, r, est toujours stricte
void aux_merge_sort(int *tmp, int *res, int l, int r)
{
  
  assert(tmp != NULL);
  assert(res != NULL);
  
  if (l >= r-1) // cas d'arrêt, segment de taille 0 ou 1
    return;

  int m = (r+l)/2;
  printf("Segment [l=%d, m=%d[\t ", l, m);
  printf("Segment [m=%d, r=%d[\n", m, r);
  
  aux_merge_sort(tmp, res, l, m); // appel récursif sur la moitié gauche.
  // entrée: tmp, sortie dans res.
  // A l'issue de cet appel, la moitié gauche [l, m] de res  est triée 
  
  aux_merge_sort(tmp, res, m, r); // appel récursif sur la moitié droite
    // entrée: tmp, sortie dans res.
   // A l'issue de cet appel, la moitié droite [m+1, r] de res  est triée

  // copie des deux segement triés dans tmp
  copy_array(tmp, res, l, r); // copie res dans tmp

  // merge les deux segments [l, m] et [m+1, r[ de tmp et range le résultat dans res
  // entrée: tmp
  // sortie: res
  merge(res, tmp, l, m, r); 
  
  return;
}
void merge_sort(int *tab, int n)
{
  assert(tab != NULL);
  assert(n >= 0);
  
  int *tmp = malloc(n*sizeof(int)); // allocation du tableau de travail
  assert(tmp != NULL); // check allocation ok
  
  copy_array(tmp, tab, 0, n);
  
  aux_merge_sort(tmp, tab, 0, n); // renvoie le resultat trié dans tab

  free(tmp);
  return;
}


int main(int argc, char *argv[])
{

  assert(argc == 4);
  
  int n = atoi(argv[1]);
  assert(n >= 1);
  int a = atoi(argv[2]);
  int b = atoi(argv[3]);

  assert(b >= a);
  
  int *tab = generate_random_array(n, a, b);

  print_array(tab, n);

  merge_sort(tab, n);
  
  print_array(tab, n);

  free(tab);
  return 0;
}
