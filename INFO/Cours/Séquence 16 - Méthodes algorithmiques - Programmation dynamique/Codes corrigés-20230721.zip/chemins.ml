(* question  3 *)
let npaths_rec m n =
  let rec c i j =
    match (i,j) with
    |(0, _) -> 1
    |(_, 0) -> 1
    |(i,j) -> (c (i-1) (j-1)) + (c (i-1) j) + (c i (j-1))
  in
  c m n
;;

npaths_rec 2 2;; (* reponse question 1*)

(* question 4 *)
let npaths_top_down_memo m n =
  let rec c i j memo =
    match (i,j) with
    |(0, _) -> memo.(0).(j) <- 1; 1
    |(_, 0) -> memo.(i).(0) <- 1; 1
    |(i,j) -> if (memo.(i).(j) = 0) then
                memo.(i).(j) <-   (c (i-1) (j-1) memo)
                                + (c (i-1)  j    memo)
                                + (c  i    (j-1) memo);
              memo.(i).(j)
  in
  let memo = Array.make_matrix (m+1) (n+1) 0 in
  c m n memo
;;

npaths_top_down_memo 2 2;; (* reponse question 1*)

(* question 4 *)
let npaths_bottom_up_memo m n =
  let memo = Array.make_matrix (m+1) (n+1) 1 in (* initialise automatique les cas de base correspondant aux bords haut (i=0)  et gauche (j=0) du tableau *)
  for i = 1 to m do
    for j = 1 to n do
      memo.(i).(j) <- memo.(i-1).(j-1) + memo.(i).(j-1) + memo.(i-1).(j)
    done
  done;
  memo.(m).(n)
;;
npaths_bottom_up_memo 2 2;; (* reponse question 1*)


(* question 5: amélioration de la complexité spatiale de la fonction itérative bottom up*)
let npaths_bottom_up_memo_better m n =
  let memo = Array.make (n+1) 1 in (* initialise automatique les cas de base correspondant aux bords haut (i=0)  et gauche (j=0) du tableau *)
  for i = 1 to m do
    let cim1jm1 = ref 1 in
    for j = 1 to n do
      let sav = memo.(j) in 
      (
        memo.(j) <- !cim1jm1  + memo.(j-1) + memo.(j);
        cim1jm1 := sav
      )
    done
  done;
  memo.(n)
;;
npaths_bottom_up_memo_better 2 2;; (* reponse question 1*)
