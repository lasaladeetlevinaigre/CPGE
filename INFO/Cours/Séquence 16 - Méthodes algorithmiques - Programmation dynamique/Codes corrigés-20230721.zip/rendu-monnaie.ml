(*************** approches récursives *********************)

let euro_system = [| 1; 2; 5; 10; 20; 50; 100; 200; 500 |];;
let uk_system_until_1971 = [| 1; 3; 6; 12; 24; 30|];;


(* approche récursive naïve *)
let change_rec amount monetary_system =
  assert(amount >= 0);
  let n = Array.length monetary_system in
  (
    assert(n > 0);
    assert(monetary_system.(0) = 1);
    let rec aux s i  =
    match (s, i) with
    |(0, _) -> 0 (* si la somme a rendre est nulle... on rend 0 pièces! *)
    |(_, 0) -> s (* si on a que des pièces de 1 euros pour rendre s euros.. on rend s pièces *)
    |(s, i) -> let vi = monetary_system.(i) in
               if (vi > s) then
                 aux s (i-1)  (* on ne peut utiliser la pièce de valeur vi, qui est trop grande, plus grande que la somme totale. Dans ce cas, on doit rendre en utilisant uniquement les pieces de 0 à (i-1)*)
               else
                 min ( aux s (i-1) ) ( 1 + (aux (s - vi) i) ) (* beaucoup trop cher... complexité exponentielle! *)
    in 
    aux amount (n-1)
  )
;;

change_rec 13 euro_system;;
change_rec 25 euro_system;;
change_rec 47 euro_system;;


change_rec 49 uk_system_until_1971;;


(* approche top to bottom avec mémoisation *)
let change_top_down_memo amount monetary_system =
  
  assert(amount >= 0);
  let n = Array.length monetary_system in
  (
    assert(n > 0);
    assert(monetary_system.(0) = 1);
    let p = (amount + 1) in (* car unité de base du système monétaire supposée égale à 1 *)
    let min_change = Array.make_matrix n p (-1) in
    let rec aux s i  =
      match (s, i) with
      |(0, _) -> 0 (* si la somme a rendre est nulle... on rend 0 pièces! *)
      |(_, 0) -> s (* si on a que des pièces de 1 euros pour rendre s euros.. on rend s pièces *)
      |(s, i) -> if (min_change.(i).(s) <> -1) then (* valeur déjà calculée !*)
                   min_change.(i).(s)
                 else
                 (
                   let vi = monetary_system.(i) in
                   if (vi > s) then
                     aux s (i-1)  (* on ne peut utiliser la pièce de valeur vi, qui est trop grande, plus grande que la somme totale. Dans ce cas, on doit rendre en utilisant uniquement les pieces de 0 à (i-1)*)
                   else
                     min ( aux s (i-1) ) ( 1 + (aux (s - vi) i) )
                 )
    in
    aux amount (n-1) 
  )
  
;;


change_top_down_memo 13 euro_system;;
change_top_down_memo 25 euro_system;;
change_top_down_memo 47 euro_system;;

change_top_down_memo 49 uk_system_until_1971;;


(****************** stratégie programmation dynamique bottom to top avec mémoisation ********)



(* min_change[i][s] on calcule pour chaque somme s représentable avec ce systeme le nombre
   minimal de pièces nécessaires quand on utilise les i premières unités monétaires *)


(* min_change[i][s] = min( 1+ min_change[i-1][s-vi] , min_change[i-1][s] ) *)
(* pour cette fonction, pour pouvoir utiliser directement les montants des 
  différentes sommes que l'on peut rendre comme indice, on ne considère que des sommets entières 
  et un système monétaire avec des unités de valeurs monéatires entières; Cela ne consistue aucunement une limitation.
  par exemple, dans le système euro, il suffit de raisonner en centimes pour que toutes les valeurs monétaires et les 
sommes soient représentées sur des entiers *)
let euro_system = [| 1; 2; 5; 10; 20; 50; 100; 200; 500 |];;
let uk_system_until_1971 = [| 1; 3; 6; 12; 24; 30|];;

let change_bottom_up_memo amount monetary_system =
  assert(monetary_system.(0) = 1);
  let p = (amount + 1) in (* car unité de base du système monétaire supposée égale à 1 *)
  let n = Array.length monetary_system in
  let min_change = Array.make_matrix n p 0 in
   for s = 0 to (p-1) do
     min_change.(0).(s) <- s (* si on n'a que l'unité de valeur de base 1 (i=0), alors il faut s pièces pour rendre la somme s *)
   done;
   
  for i = 0 to (n-1) do
    min_change.(i).(0) <- 0 (* pour rendre la somme 0, il faut 0 pièces, quelque soit le nombre d'unité de valeurs i à dispo *)
  done;

  for i = 1 to (n-1) do
    
    let vi = monetary_system.(i) in (* unité monétaire numéro i*)
    
    for s = 1 to (p-1) do
      min_change.(i).(s) <-  min_change.(i-1).(s);      
      let remain = s - vi in
      (
         
        if (remain >= 0) then
        (
          (* attention ici, on utilise min_change.(i).(remain) qui a été calculé juste avant pour la somme,remain, plus petite, sur la meme ligne! *)
          if (1 + min_change.(i).(remain) < min_change.(i).(s) ) then
            min_change.(i).(s) <- 1 + min_change.(i).(remain)
        )
      )
    done
  done;
  min_change.(n-1).(amount)
;;


change_bottom_up_memo 13 euro_system;;
change_bottom_up_memo 25 euro_system;;
change_bottom_up_memo 47 euro_system;;


change_bottom_up_memo 49 uk_system_until_1971;; (* on trouve la bonne solution avec 3 pièces: 49 =  2 * unité_monetaire(24) + 1 *)


(* amélioration de la mémoisation : on garde toutes les sommets pour un i données
   on peut mettre à jour intelligemment sans conserver les i d'avant *)
let change_bottom_up amount monetary_system =
  assert(monetary_system.(0) = 1);
  let p = (amount + 1) in (* car unité de base du système monétaire supposée égale à 1 *)
  let n = Array.length monetary_system in
  let min_change = Array.make p 0 in
   for s = 0 to (p-1) do
     min_change.(s) <- s (* si on n'a que l'unité de valeur de base 1 (i=0), alors il faut s pièces pour rendre la somme s *)
   done;
   
  for i = 1 to (n-1) do
    
    let vi = monetary_system.(i) in (* unité monétaire numéro i*)
    
    for s = 1 to (p-1) do
      let remain = s - vi in
      (         
        if (remain >= 0) then
        (
          (* attention ici, on utilise min_change.(i).(remain) qui a été calculé juste avant pour la somme,remain, plus petite, sur la meme ligne! *)
          if (1 + min_change.(remain) < min_change.(s) ) then
            min_change.(s) <- 1 + min_change.(remain)
        )
      )
    done
  done;
  (min_change.(amount), min_change)
;;


change_bottom_up 13 euro_system;;
change_bottom_up 25 euro_system;;
change_bottom_up 47 euro_system;;


change_bottom_up 49 uk_system_until_1971;; 

let print_change change monetary_system =
  let n = Array.length monetary_system in
  for i = 0 to (n-1) do
    if (change.(i)  > 0) then
      Printf.printf "\n%d entité(s) de valeur %d" change.(i) monetary_system.(i)
  done;
  Printf.printf "\n"
;;

(* routine de reconstruction pour avoir exactement la solution, et pas uniquement la valeur solution *)
let get_change amount monetary_system =
  let (nb, min_change) = change_bottom_up amount monetary_system in
  let n = Array.length  monetary_system in
  let change = Array.make n 0 in (* contient le nombre d'entités à rendre pour chaque unité de valeur *)
  let s = ref amount in
  let i = ref (n-1) in
  while (!s > 0) do
    Printf.printf "%d " !i;
    let vi = monetary_system.(!i) in
    if (!s >= vi) then
    (
      if (min_change.(!s) - min_change.(!s-vi) = 1) then
        (
          change.(!i) <- change.(!i) + 1;
          s := !s - vi
        )
      else
        i := !i -1 
    )
    else
      i := !i -1 
  done;
  print_change change monetary_system
;;


get_change 13 euro_system;;
get_change 25 euro_system;;
get_change 47 euro_system;;
get_change 49 uk_system_until_1971;; 

(*************** approche gloutonne *********************)



(* methode gloutonne: on "fait rentrer" l'unité monétaire (pièce) de plus grande valeur, 
   puis on calcule la somme restante, et à nouveau on cherche à faire rentrer la plus
   grande unité monétaire...etc *)

(* précondition: monetary_system est un tableau d'entiers trié par ordre croissant
  qui représente les valeurs des unités monétaires utilisées dans un certain système monétaire 
  avec la première unité de valeur valant 1, précondition vérifiée dans le code *)
(* précondition: s somme à rendre, positive ou null, précondition vérifiée dans le code *)
let change_greedy amount monetary_system =
  
  assert(monetary_system.(0) = 1);
  
  let n = Array.length monetary_system in
  let change = Array.make n 0 in (* tableau qui contiendra, pour chaque unité monétaire, le nombre de ces unités à rendre *)
  let remain = ref amount in (* somme restant à rendre *)
  let i = ref (n-1) in
  let nb_change = ref 0 in
  
  while (!remain >= monetary_system.(0)) do
    if (monetary_system.(!i) > !remain ) then
      i := !i - 1
    else
      (        
        change.(!i) <- change.(!i) + 1;
        nb_change := !nb_change + 1;
        remain := !remain - monetary_system.(!i);
        Printf.printf "Unité de valeur %d choisie:  somme restante à rendre = %d\n" monetary_system.(!i) !remain;
      )
  done; 
  print_change change monetary_system;
  !nb_change
;;


let euro_system = [| 1; 2; 5; 10; 20; 50; 100; 200; 500|];;
change_greedy 13 euro_system;;
change_greedy 25 euro_system;;
change_greedy 47 euro_system;;


(* https://fr.wikipedia.org/wiki/Decimal_Day *)
let uk_system_until_1971 = [| 1; 3; 6; 12; 24; 30|];;
change_greedy 49 uk_system_until_1971;; (* la solution gloutonne ne donne pas le resultat optimal minimisant le nombre d'entités de valeur rendues: on peut rendre 2 * 24 + 1 comme les méthodes précédentes ont permis de le calculer *)

























(* version greedy pour des systèmes avec flottants, pas super pertinent car on peut toujours parler en centimes... *)

let euro_system = [| 0.01; 0.02; 0.05; 0.1; 0.2; 0.5; 1.; 2.; 5.; 10.; 20.; 50.; 100.; 200.; 500.|];;


let print_change change monetary_system =
  let n = Array.length monetary_system in
  for i = 0 to (n-1) do
    if (change.(i)  > 0) then
      Printf.printf "\n%d entité(s) de valeur %f" change.(i) monetary_system.(i)
  done;
  Printf.printf "\n"
;;



(* methode gloutonne: on "fait rentrer" l'unité monétaire (pièce) de plus grande valeur, 
   puis on calcule la somme restante, et à nouveau on cherche à faire rentrer la plus
   grande unité monétaire...etc *)

(* précondition: monetary_system est un tableau de flottants trié par ordre croissant
  qui représente les valeurs des unités monétaires utilisées dans un certain système monétaire *)
(* précondition: s sommet à rendre, positive ou null, vérifiée dans le code *)
let change_greedy s monetary_system =
  
  assert(s >= 0.);
  
  let n = Array.length monetary_system in
  let change = Array.make n 0 in (* tableau qui contiendra, pour chaque unité monétaire, le nombre de ces unités à rendre *)
  let remain = ref s in (* somme restant à rendre *)
  let i = ref (n-1) in
  let nb_change = ref 0 in
  while (!remain >= monetary_system.(0)) do
    if (monetary_system.(!i) > !remain && ( (monetary_system.(!i) -. !remain) > monetary_system.(0) ) ) then
      i := !i - 1
    else
      (        
        change.(!i) <- change.(!i) + 1;
        nb_change := !nb_change + 1;
        remain := !remain -. monetary_system.(!i);
        Printf.printf "Unité de valeur %2.4f choisie:  somme restante à rendre = %f\n" monetary_system.(!i) !remain;
      )
  done; 
  print_change change monetary_system;
  !nb_change
;;


change_greedy 13. euro_system;;
change_greedy 25.37 euro_system;;
change_greedy 25.305 euro_system;;
change_greedy 47.25 euro_system;;
change_greedy 47.2505 euro_system;;

let uk_system_until_1971 = [| 1.; 3.; 6.; 12.; 24.; 30.|];;
change_greedy 49. uk_system_until_1971;; (* la solution gloutonne ne donne pas le resultat optimal minimisant le nombre d'entités de valeur rendues: on peut rendre 2 * 24 + 1 *)
