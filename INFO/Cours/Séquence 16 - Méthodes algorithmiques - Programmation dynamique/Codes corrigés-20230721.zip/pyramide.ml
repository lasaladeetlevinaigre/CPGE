let p1 = [|
    [|3|];
    [|1;4|];
    [|1; 5; 9|];
    [|2; 6; 5; 3|];
    [|5; 8; 9; 7; 9|]
  |];;


let p2 = [|
    [|1|];
    [|2;1|];
    [|2; 1; 1|];
    [|2; 1; 1; 1|];
    [|2; 1; 1; 1; 10|]
  |];;


(* méthode exhaustive *)




(* méthode gloutonne *)
let pyramide_greedy p =
  let n = Array.length p in
  let s = ref p.(0).(0) in
  let j = ref 0 in
  for i = 1 to (n-1) do
    let l = p.(i).(!j) and r = p.(i).(!j+1) in
    if (l < r) then (* si le fils droit est plus grand, on prend le chemin de droite *)
      (
        s := !s + r;
        j := !j + 1
      )
    else
      s := !s + l;   
  done;
  !s
;;


pyramide_greedy p1;; (* greedy donne le bon résultat *)
pyramide_greedy p2;; (* greedy ne donne pas le bon résultat! *)

(* méthode récursive basique top to bottom *)

(* il est difficile de la rendre récursive terminale a première vue! *)
let pyramide_rec p =
  let n     = Array.length p in
  let rec aux p i j =
    if (i = n) then 0
    else
      p.(i).(j) + max (aux p (i+1) j) (aux p (i+1) (j+1))
  in
  aux p 0 0
;;

pyramide_rec p1;; 
pyramide_rec p2;; 

(* méthode récursive avec mémoisation *)
let pyramide_rec_memo p =
  let n = Array.length p in
  let s = Array.make n [||] in

  (
    for i = 0 to (n-1) do
    s.(i) <- Array.make (i+1) (-1)
    done;
  
    let rec aux p s i j =
      if (i = n) then 0
      else
        if (s.(i).(j) <> -1) then (* utilisation du résultat de la somme de gauche mémoisié, s'il existe *)
          s.(i).(j)
        else
        (
           s.(i).(j) <- p.(i).(j) + ( max (aux p s (i+1) j) (aux p s (i+1) (j+1)) );
           s.(i).(j)
        )
  in
  aux p s 0 0
  )
;;

p1;;
pyramide_rec_memo p1;; 
pyramide_rec_memo p2;; 


(* mémoisation avec une table de hachage plutôt qu'un  tableau bi dimensionnel *)
let pyramide_rec_memo p =
  let n = Array.length p in
  let s = Hashtbl.create (n*(n+1)/2) in
  let rec aux p s i j =
    if (i = n) then 0
    else      
      try
        Hashtbl.find s (i,j) (* on aurait aussi pu utiliser find_opt et gerer l'absence de mémoisation de cette valeur avec la deconstruction du type option retourné...*)
      with
        Not_found ->
        let v = p.(i).(j) + ( max (aux p s (i+1) j) (aux p s (i+1) (j+1)) )
        in
        (
          Hashtbl.add s (i,j) v;
          v
        )
  in
  aux p s 0 0
;;

p1;;
pyramide_rec_memo p1;; 
pyramide_rec_memo p2;;



(* méthode itérative bottom to top *)

let print_pyramide p =
  let n = Array.length p in
  Printf.printf "\n";
  for i=0 to (n-1) do
    Array.iter (fun x -> Printf.printf "%d " x) p.(i);
    Printf.printf "\n"
  done;
  Printf.printf "\n"
;;

let pyramide_bottom_up p =
  let n = Array.length p in
  let s = Array.make n [||] in
  for i = 0 to (n-1) do
    s.(i) <- Array.copy p.(i)
  done;
  
  for i = (n-2) downto 0 do
    for j = 0 to i do
      s.(i).(j) <- s.(i).(j) + ( max s.(i+1).(j)  s.(i+1).(j+1) )
    done;
    print_pyramide s
  done;
  s.(0).(0)
;;

p1;;
print_pyramide p1;;
pyramide_bottom_up p1;; 
pyramide_bottom_up p2;;

(* méthode itérative bottom to top optimisée *)
let pyramide_bottom_up_better p =
  let n = Array.length p in
  let s = Array.copy p.(n-1) in (* un tableau unidimensionnel, correspondant au niveau que l'on est en train de traiter, suffit. On l'initialise avec le niveau à la base de la pyramide *)
  for i = (n-2) downto 0 do
    for j = 0 to i do
      s.(j) <- p.(i).(j) + ( max s.(j)  s.(j+1) )
    done;
  done;
  s.(0)
;;

p1;;
print_pyramide p1;;
pyramide_bottom_up_better p1;; 
pyramide_bottom_up_better p2;;
