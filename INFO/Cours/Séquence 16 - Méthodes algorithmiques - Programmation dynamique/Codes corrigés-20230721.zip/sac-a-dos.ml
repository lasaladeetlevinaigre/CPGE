let gain_rec tab_obj wmax =
  let rec g tab_obj wmax i =
    if (i = -1) then (* cas d'arrêt : aucun objet à mettre dans le sac *)
      0
    else if (wmax <= 0) then (* cas d'arrêt : sac qui ne peut plus rien contenir *)
      0
    else
      (
        let (vi, wi) = tab_obj.(i)  in        
        if (wi > wmax) then (* l'objet i seul ne rentre déjà pas dans le sac à dos! *)
          g tab_obj wmax (i-1)
        else
          let gain_without_obji = g tab_obj wmax (i-1) and
              gain_with_obji = vi + (g tab_obj (wmax-wi) (i-1))
          in
          max gain_without_obji gain_with_obji

      )
  in
  let nobj = Array.length tab_obj in
  g tab_obj wmax (nobj-1)
;;

(* tableaux de 4 objets. 
   Un objet est représenté par un couple 
  (v valeur de l'abjet, w poids de l'objet) *)
let tab_obj = [| (5, 5); (3, 3); (7, 10); (4, 3)|];;

gain_rec tab_obj 7;;


(* version top-down (récursive) avec mémoisation *)
let gain_top_down_memo tab_obj wmax =
  let rec g tab_obj wmax i memo =
    if (i = 0) then (* cas d'arrêt : aucun objet à mettre dans le sac *)
      memo.(wmax).(i)
    else if (wmax <= 0) then (* cas d'arrêt : sac qui ne peut plus rien contenir *)
      memo.(0).(i)
    else
    (
      if memo.(wmax).(i) = 0 then (* pas encore calculé *)
        (
          let (vi, wi) = tab_obj.(i-1)  in        
          if (wi > wmax) then (* l'objet i seul ne rentre déjà pas dans le sac à dos! *)
            memo.(wmax).(i) <- g tab_obj wmax (i-1) memo
          else  
            let gain_without_obji =  g tab_obj wmax (i-1) memo and
                gain_with_obji =  vi + (g tab_obj (wmax-wi) (i-1) memo)
            in
            memo.(wmax).(i) <- max gain_without_obji gain_with_obji
        );
        memo.(wmax).(i)
    )
  in
  let nobj = Array.length tab_obj in
  let memo = Array.make_matrix  (wmax+1) (nobj+1) 0 in
  g tab_obj wmax nobj memo
;;

let tab_obj = [| (5, 5); (3, 3); (7, 10); (1, 3)|];;

gain_top_down_memo tab_obj 9;;


(* version bottom-up (itérative) avec mémoisation *)
let gain_bottom_up_memo tab_obj wmax =
  let nobj = Array.length tab_obj in
  let memo = Array.make_matrix  (wmax+1) (nobj+1) 0 in
  for w = 1 to wmax do
    for i = 1 to nobj do
      let (vi, wi) = tab_obj.(i-1) in
      if (wi > w) then (* l'objet i seul ne rentre déjà pas dans le sac à dos! *)
        memo.(w).(i) <- memo.(w).(i-1)
      else
        memo.(w).(i) <- max (vi+memo.(w-wi).(i-1))  memo.(w).(i-1)
    done   
  done;
  memo.(wmax).(nobj);
;;


let tab_obj = [| (5, 5); (3, 3); (7, 10); (1, 3)|];;
gain_bottom_up_memo tab_obj 7;;



(* version bottom-up (itérative) avec mémoisation améliorée*)
let gain_bottom_up_memo_with_selected_obj tab_obj wmax =
  let nobj = Array.length tab_obj in
  let memo = Array.make_matrix  (wmax+1) (nobj+1) 0 in
  let selected_obj = Stack.create () in
  for w = 1 to wmax do
    for i = 1 to nobj do
      let (vi, wi) = tab_obj.(i-1) in
      if (wi > w) then (* l'objet i seul ne rentre déjà pas dans le sac à dos! *)
        memo.(w).(i) <- memo.(w).(i-1)
      else
        (
           if (vi+ memo.(w-wi).(i-1) > memo.(w).(i-1)) then
            (
              if (w = wmax) then
                Stack.push (i-1) selected_obj;
              memo.(w).(i) <- vi + memo.(w-wi).(i-1)
            )
           else
             memo.(w).(i) <- memo.(w).(i-1)
        )
    done   
  done;
  (memo.(wmax).(nobj), selected_obj)
;;



let tab_obj = [| (5, 5); (3, 3); (7, 10); (1, 3); (4, 1)|];;
let (g, selected) = gain_bottom_up_memo_with_selected_obj tab_obj 12;;
Stack.iter (fun x -> Printf.printf "%d " x) selected;;
