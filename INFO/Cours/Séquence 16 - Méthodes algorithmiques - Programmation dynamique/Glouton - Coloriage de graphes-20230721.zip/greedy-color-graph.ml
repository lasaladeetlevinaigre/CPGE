#use "./Wgraph.ml"



(* Construction du graphe g1 *)
let g1 = Wgraph.init_no_edge 8 false;;
Wgraph.add_edge g1 0 1 1.;
Wgraph.add_edge g1 0 2 1.;
Wgraph.add_edge g1 2 1 1.;
Wgraph.add_edge g1 3 5 1.;
Wgraph.add_edge g1 4 5 1.;
Wgraph.add_edge g1 5 7 1.;;


 

let arbre = Wgraph.init_no_edge 11 false;;
Wgraph.add_edge arbre 0 1 1.0;
Wgraph.add_edge arbre 1 2 1.0;
Wgraph.add_edge arbre 1 3 1.0;
Wgraph.add_edge arbre 3 4 1.0;
Wgraph.add_edge arbre 4 5 1.0;
Wgraph.add_edge arbre 5 6 1.0;
Wgraph.add_edge arbre 0 7 1.0;
Wgraph.add_edge arbre 7 8 1.0;
Wgraph.add_edge arbre 8 9 1.0;
Wgraph.add_edge arbre 8 10 1.0;;



let biparti = Wgraph.init_no_edge 8 false;;
Wgraph.add_edge biparti 0 3 1.0;
Wgraph.add_edge biparti 0 5 1.0;
Wgraph.add_edge biparti 0 7 1.0;
Wgraph.add_edge biparti 2 1 1.0;
Wgraph.add_edge biparti 2 5 1.0;
Wgraph.add_edge biparti 2 7 1.0;
Wgraph.add_edge biparti 4 1 1.0;
Wgraph.add_edge biparti 4 3 1.0;
Wgraph.add_edge biparti 4 7 1.0;
Wgraph.add_edge biparti 6 1 1.0;
Wgraph.add_edge biparti 6 3 1.0;
Wgraph.add_edge biparti 6 5 1.0;;

let print_list l =
  List.iter (fun c -> Printf.printf "%d " c) l
;;


let first_free l nv =
  let free = Array.make nv true in
  (List.iter (fun c -> if (c >= 0) then (free.(c) <- false)) l;
   let rec find_smallest_free free i = if (free.(i) = true) then i else find_smallest_free free (i+1) in
   find_smallest_free free 0
  )
;;

let greedy_color g =
  
  let nv = Wgraph.number_of_vertices g in
  let color_tab = Array.make nv (-1) in
  let nb_colors_max = ref (-1) in
  for u = 0 to (nv-1) do
    let lsucc = Wgraph.succ g u in
    let list_neighbours_colors = List.map (fun (v, _) -> color_tab.(v)) lsucc in
    let smallest_available_color = first_free list_neighbours_colors nv in
    (
      color_tab.(u) <- smallest_available_color;
      if ( smallest_available_color > !nb_colors_max ) then
        nb_colors_max := smallest_available_color
    )
  done;
  (!nb_colors_max, color_tab)
;;

greedy_color g1;;
greedy_color arbre;;
greedy_color biparti;;


let greedy_color g order  =
  
  let nv = Wgraph.number_of_vertices g in
  let color_tab = Array.make nv (-1) in
  let nb_colors_max = ref (-1) in
  let set_color u =
    let lsucc = Wgraph.succ g u in
    let list_neighbours_colors = List.map (fun (v, _) -> color_tab.(v)) lsucc in
    let smallest_available_color = first_free list_neighbours_colors nv in
    (
      color_tab.(u) <- smallest_available_color;
      if ( smallest_available_color > !nb_colors_max ) then
        nb_colors_max := smallest_available_color
    )
  in
  List.iter set_color order;
  (!nb_colors_max, color_tab)
;;

(* l'ordre de parcours des sommets pour l'attribution des couleurs change complètement le résultat
  par exemple, sur le graphe biparti, en parcourant les sommets de X (0, 2, 4, 6), puis ceux de Y (1, 3, 5, 7), on obtient un
 coloriage optimal à 2 couleurs *)
greedy_color biparti [0; 2; 4; 6; 1; 3; 5; 7];;
