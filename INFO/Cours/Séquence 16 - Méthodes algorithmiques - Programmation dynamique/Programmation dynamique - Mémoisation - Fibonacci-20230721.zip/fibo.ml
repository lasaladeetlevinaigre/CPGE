let rec fibo n =
  assert(n >= 0); 
  match n with
  |0 -> 0
  |1 -> 1
  | _ -> (fibo (n-1)) + (fibo (n-2))
;;
fibo (-1);;
fibo 5;;
fibo 7;;

let fibo_top_down_memo n =
  assert(n >= 0);  
  let rec aux n memo =  (* top-down -> récursif *)
    match n with
    |0 -> 0
    |1 -> 1
    | _ -> if (memo.(n) = 0) then
             (memo.(n) <- (aux (n-1) memo) + (aux (n-2) memo); memo.(n) )
           else (* sous-problème deja resolu *)
             memo.(n)
  in
  let memo = Array.make (n+1) 0 in (* tableau de stockage, memoisation *)
  memo.(1) <- 1;
  aux n memo;  
;;

fibo_top_down_memo 5;;
fibo_top_down_memo 7;;


let fibo_bottom_up_memo n =
  assert(n >= 0);  
  let memo = Array.make (n+1) 0 in (* tableau de stockage, memoisation *)
  (
    memo.(1) <- 1;
    for i = 2 to n do (* bottom-up -> iteratif *)
      memo.(i) <- memo.(i-1) + memo.(i-2)
    done;
    memo.(n)
  )
;;

fibo_bottom_up_memo 5;;
fibo_bottom_up_memo 7;;

let fibo_bottom_up_memo_optim n =
  assert(n >= 0);
  let un = ref 1 and unm1 = ref 0 in (* 2 variables de stockage uniquement *)
  (
    for i = 2 to n do
      let a = !un in
      (
        un := !un + !unm1;
        unm1 := a
      )
    done;
    !un
  )
;;

fibo_bottom_up_memo_optim 5;;
fibo_bottom_up_memo_optim 7;;
