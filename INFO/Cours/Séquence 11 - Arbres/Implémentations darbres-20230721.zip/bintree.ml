(* ex1 *)

(*q1*)
type 'a bintree = Empty | Node of ('a bintree) * 'a * ('a bintree);;

(*q2*)

let arbre_enonce = Node(Node(Empty, 1, Empty), 2, Node(Node(Empty, 4, Empty), 3, Node(Empty, 5, Empty)));;

(*q3*)
let peigne_gauche = Node(Node(Node(Node(Empty, 3, Empty), 4, Empty), 2, Empty), 1, Empty);;
let peigne_droit = Node(Empty, 1, Node(Empty, 2, Node(Empty, 3, Node(Empty, 4, Empty))));;

(*q4*)

let rec bintree_number_of_nodes t =
  match t with
  |Empty -> 0
  |Node(l, _, r) -> 1 + (bintree_number_of_nodes l) + (bintree_number_of_nodes r)
;;

bintree_number_of_nodes arbre_enonce;;
bintree_number_of_nodes peigne_gauche;;
bintree_number_of_nodes peigne_droit;;

(*q5*)
let rec bintree_height t =
  match t with
  | Empty -> -1
  | Node(l, _, r) -> 1+ max (bintree_height l) (bintree_height r)
;;

bintree_height arbre_enonce;;
bintree_height peigne_gauche;;
bintree_height peigne_droit;;

(*q6*)
let rec bintree_leaves t =
  match t with
  | Node(Empty, _, Empty) -> 1
  | Node(l, _, Empty) -> (bintree_leaves l)
  | Node(Empty, _, r) -> (bintree_leaves r)
  | Node(l, _, r) -> (bintree_leaves l) + (bintree_leaves r)
  |_ -> failwith "On ne doit pas arriver ici..."
;;

bintree_leaves arbre_enonce;;
bintree_leaves peigne_gauche;;
bintree_leaves peigne_droit;;

(*q7*)
let rec bintree_max t =
  match t with
  |Node(Empty, v, Empty) -> v
  |Node(l, v, Empty) -> max v (bintree_max l)
  |Node(Empty, v, r) -> max v (bintree_max r) 
  |Node(l, v, r) -> max v (max (bintree_max l) (bintree_max r))
  |_ -> failwith "On ne doit pas arriver ici..."
;;

bintree_max arbre_enonce;;
bintree_max peigne_gauche;;
bintree_max peigne_droit;;


(*q8*)
let rec bintree_sum t =
  match t with
  |Node(Empty, v, Empty) -> v
  |Node(l, v, Empty) ->  v + (bintree_sum l)
  |Node(Empty, v, r) -> v + (bintree_sum r) 
  |Node(l, v, r) -> v + (bintree_sum l) + (bintree_sum r)
  |_ -> failwith "On ne doit pas arriver ici..."
;;

bintree_sum arbre_enonce;;
bintree_sum peigne_gauche;;
bintree_sum peigne_droit;;


(* ex2 *)

(*q1*)
let rec bintree_preorder t =
  match t with
  |Empty -> ()
  |Node(l, v, r) -> print_char ' '; print_int v;  bintree_preorder l; bintree_preorder r
;;

bintree_preorder arbre_enonce;;
bintree_preorder peigne_gauche;;
bintree_preorder peigne_droit;;

(*q2*)
let rec bintree_inorder t =
  match t with
  |Empty -> ()
  |Node(l, v, r) ->  bintree_inorder l; print_int v; print_char ' ';  bintree_inorder r
;;

bintree_inorder arbre_enonce;;
bintree_inorder peigne_gauche;;
bintree_inorder peigne_droit;;

let rec bintree_postorder t =
  match t with
  |Empty -> ()
  |Node(l, v, r) -> bintree_postorder l; bintree_postorder r;  print_int v; print_char ' '
;;

bintree_postorder arbre_enonce;;
bintree_postorder peigne_gauche;;
bintree_postorder peigne_droit;;

(*q3 et 4*)

let rec bintree_preorder_list t=
  match t with
  |Empty -> [ ]
  |Node(l, v, r) -> (v::bintree_preorder_list l)@ (bintree_preorder_list r)
;;

bintree_preorder_list arbre_enonce;;
bintree_preorder_list peigne_gauche;;
bintree_preorder_list peigne_droit;;

let bintree_preorder_list_version2 t =
let rec bintree_preorder_aux t acc =
  match t with
  |Empty -> acc
  |Node(l, v, r) -> bintree_preorder_aux r (bintree_preorder_aux l (v::acc))
in
List.rev (bintree_preorder_aux t [])
;;

bintree_preorder_list arbre_enonce;;
bintree_preorder_list_version2 arbre_enonce;;
bintree_preorder_list peigne_gauche;;
bintree_preorder_list_version2 peigne_gauche;;
bintree_preorder_list peigne_droit;;
bintree_preorder_list_version2 peigne_droit;;

let rec bintree_inorder_list t=
  match t with
  |Empty -> [ ]
  |Node(l, v, r) -> (bintree_inorder_list l)@ (v::(bintree_inorder_list r))
;;

bintree_inorder_list arbre_enonce;;
bintree_inorder_list peigne_gauche;;
bintree_inorder_list peigne_droit;;

let bintree_inorder_list_version2 t =
let rec bintree_inorder_aux t acc =
  match t with
  |Empty -> acc
  |Node(l, v, r) -> bintree_inorder_aux r (v::(bintree_inorder_aux l acc))
in
List.rev (bintree_inorder_aux t [])
;;

bintree_inorder_list arbre_enonce;;
bintree_inorder_list_version2 arbre_enonce;;
bintree_inorder_list peigne_gauche;;
bintree_inorder_list_version2 peigne_gauche;;
bintree_inorder_list peigne_droit;;
bintree_inorder_list_version2 peigne_droit;;

let rec bintree_postorder_list t=
  match t with
  |Empty -> [ ]
  |Node(l, v, r) -> (bintree_postorder_list l)@ (bintree_postorder_list r)@[v]
;;

bintree_postorder_list arbre_enonce;;
bintree_postorder_list peigne_gauche;;
bintree_postorder_list peigne_droit;;

let bintree_postorder_list_version2 t =
let rec bintree_postorder_aux t acc =
  match t with
  |Empty -> acc
  |Node(l, v, r) -> v::(bintree_postorder_aux r (bintree_postorder_aux l acc))
in
List.rev (bintree_postorder_aux t [])
;;

bintree_postorder_list arbre_enonce;;
bintree_postorder_list_version2 arbre_enonce;;
bintree_postorder_list peigne_gauche;;
bintree_postorder_list_version2 peigne_gauche;;
bintree_postorder_list peigne_droit;;
bintree_postorder_list_version2 peigne_droit;;

(* q5 aucune de ces fonctions n'est terminale: on doit effectuer des opérations utilisant les retours des appels récursifs... *)

(* ex3 *)

(*q1*)
let bintree_max_sum t =
  let rec poids t acc =
    match t with
    | Empty -> acc
    | Node(l,v,r)-> max (poids l (acc+v)) (poids r (acc+v))
  in match t with
     |Empty -> failwith "Arbre vide!"
     |Node(l, v, r) -> max (poids l v) (poids r v)
;;


bintree_max_sum arbre_enonce;;
bintree_max_sum peigne_gauche;;

let bintree_max_sum_path t =
  let rec poids t acc acc_l =
    match t with
    | Empty -> (acc, acc_l)
    | Node(l,v,r)-> let (pg,lg) = (poids l (acc+v) (v::acc_l)) and
                        (pd,ld) = (poids r (acc+v) (v::acc_l)) in
                    if (pg > pd) then (pg, lg) else (pd, ld)
  in match t with
     |Empty -> failwith "Arbre vide!"
     |Node(l, v, r) -> let (pg,lg) = (poids l v [v]) and (pd, ld) = (poids r v [v]) in
                       if (pg > pd) then (List.rev lg) else (List.rev ld)
;;

bintree_max_sum_path arbre_enonce;;
bintree_max_sum_path peigne_gauche;;

(*ex4*)

let rec bintree_create_perfect h =
  if (h = -1) then
    Empty
  else
    Node(bintree_create_perfect (h-1), h, bintree_create_perfect (h-1))
;;

let t = bintree_create_perfect 3;;
bintree_preorder t;;


