#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>

//#define elt_type float
//#define elt_fmt  "%f"

#define elt_type double
#define elt_fmt  "%lf"

//#define elt_type int
//#define elt_fmt  "%d"

//#define elt_type char
//#define elt_fmt  "%c"

//#define elt_type bool
//#define elt_fmt  "%d"


struct s_cell
{
  elt_type       val; // valeur contenue dans ce maillon
  struct s_cell *addr_next; // pointeur contenant l'adresse
                            // du maillon suivant
};

typedef struct s_cell cell;

struct s_stack
{
  int siz;
  cell        *addr_first;
};

typedef struct s_stack stack;


stack *stack_create()
{
  stack *l = malloc(sizeof(stack));
  l->siz = 0;
  l->addr_first = NULL;
  return l;
}

// empilement
void stack_push(elt_type v, stack *l)
{
  assert(l != NULL);
  cell *c = malloc(sizeof(cell));
  c->val = v;
  c->addr_next = l->addr_first;
  l->addr_first = c;
  l->siz = l->siz+1;

  return;
}

int stack_length(stack *l)
{
  assert(l != NULL);
  return l->siz;
}

bool stack_is_empty(stack *l)
{
  assert(l != NULL);
  if (l->siz == 0)
    return true;
  return false;
}

// lecture de la valeur en haut de la pile
elt_type stack_top(stack *l)
{
  assert(l != NULL);
  cell *c = l->addr_first;

  assert(c != NULL);
  
  return c->val;
}

// récupération de la valeur en haut de la pile et dépilement
elt_type stack_pop(stack *l)
{
  assert(l != NULL);
  cell *c = l->addr_first;

  assert(c != NULL);
  
  int v = c->val;

  l->addr_first = c->addr_next;
  
  free(c);

  l->siz = l->siz - 1;
  
  return v;
}


void stack_print(stack *l)
{
  cell *c = l->addr_first;

  printf("\n %d elements:\n", l->siz);
  printf("-----\n");
  while (c != NULL)
  {
    printf(elt_fmt, c->val);
    printf("\n");
    c = c->addr_next;
  }
  printf("-----\n");
  return;
}


// le passage par adresse est nécessaire pour être certain
// de bien remettre l'adresse du stack à NULL
void stack_free(stack **addr_s)
{
  stack *s = *addr_s;
  cell  *c = s->addr_first;
  cell  *tmp = NULL;
  
  while (c != NULL)
  {
    tmp = c;
    c = c->addr_next;
    free(tmp);
  }
  free(s);
  *addr_s = NULL;

  return;
}

int main(void)
{
  stack *l = stack_create();

  stack_push(5.1, l);
  stack_push(6.3, l);
  
  stack_print(l);
  printf(elt_fmt, stack_pop(l));
  stack_print(l);
  stack_push(7.1, l);
  stack_push(-1.2, l);
  stack_push(3.0, l);

  
  
  stack_print(l);

  stack_push(31.1, l);
  stack_print(l);
  printf(elt_fmt, stack_pop(l));
  stack_print(l);
  printf(elt_fmt, stack_pop(l));

  
  stack_print(l);

  printf(elt_fmt, stack_pop(l));
  printf(elt_fmt, stack_pop(l));
  printf(elt_fmt, stack_pop(l));
  stack_free(&l);
  
  return 0;

}
