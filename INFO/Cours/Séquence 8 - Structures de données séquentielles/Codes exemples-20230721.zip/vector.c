#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#define elt_type char
#define elt_fmt "%c "

struct vector
{
  int siz;
  int siz_max;
  elt_type *data;
};

typedef struct vector vector;

vector *vector_create(int s_max)
{
  vector *v = malloc(sizeof(vector));
  v->siz_max = s_max;
  v->siz = 0;
  if (s_max > 0)
    v->data = calloc(s_max, sizeof(elt_type));
  else
  {
    v->siz_max = 0;
    v->data = NULL;
  }

  return v;
}

int vector_length(vector *v)
{
  assert(v != NULL);
  return v->siz;
}
void vector_set(vector *v, int i, elt_type x)
{
  assert(v != NULL);
  assert(i >= 0 && i < v->siz);
  v->data[i] = x;
  return;
}

elt_type vector_get(vector *v, int i)
{
  assert(v != NULL);
  assert(i >= 0 && i < v->siz);
  return v->data[i];
}


void vector_free(vector **addr_v)
{
  assert(addr_v != NULL);
  vector *v = *addr_v;

  assert(v != NULL);

  assert(v->data != NULL);
  free(v->data);
  *addr_v = NULL;
  
  return;
}

void vector_resize(vector *v, int s)
{
  assert(v != NULL);
  assert(s >= 0);
  elt_type *old_data = NULL;
  
  if (s < v->siz_max)
  {
    v->siz = s;
    return;
  }
  // on multiplie par 2 la capacité de l'ancien tableau et on regarde
  // si cela suffit à avoir une capacité au moins aussi grande
  // que la nouvelle capacité demandée
  v->siz_max = 2*v->siz_max;

  // si ce n'est pas le cas, on force la nouvelle capacité à la
  // nouvelle capacité demandée
  if (s > v->siz_max)
    v->siz_max = s;
 
  // on recopie les éléments de l'ancien tableau dans le nouveau
  if (v->siz > 0)
  {
     old_data = v->data;
     assert(old_data != NULL);
  }
  
  // on réalloue un tableau plus grand dans le tas
  printf("Reallocation mémoire: ");
  printf("siz=%d siz_max=%d\n", v->siz, v->siz_max);
  v->data = calloc(v->siz_max, sizeof(elt_type));

  // on recopie les éléments de l'ancien tableau dans le nouveau
  if (v->siz > 0)
  {
     for (int j = 0; j < v->siz; j++)     
       v->data[j] = old_data[j];
     
      // on libère l'espace de l'ancien tableau qui avait été alloué dans le tas
     free(old_data);
  }
  
  v->siz = s;
  return;
}






/* Fonctions exposées pour la structure de pile 
   utilisant un tableau redimensionnable */

typedef struct vector stack;

stack *stack_create(void)
{  
  return vector_create(0);
}

void stack_push(stack *v, elt_type x)
{
  assert(v != NULL);
  int n = vector_length(v);

  vector_resize(v, n+1);
  vector_set(v, n, x);
  return;
}

elt_type stack_top(stack *v)
{
  assert(v != NULL);
  int n = vector_length(v);
  assert(n > 0);  
  return vector_get(v, n-1);
}

elt_type stack_pop(stack *v)
{
  assert(v != NULL);
  int n = vector_length(v);
  assert(n >= 0);
  vector_resize(v, n-1); // n'entrainera jamais de realloc,
                         // permet juste de mettre à jour siz
  return vector_get(v, n-1);
}

void stack_print(stack *v)
{
  assert(v != NULL);
  
  for (int j = v->siz-1; j >= 0; j--)
    printf(elt_fmt, v->data[j]);
  printf("\n");
  return;
}

void stack_free(stack **addr_v)
{
  assert(addr_v != NULL);
  vector_free(addr_v);
  return;
}

int main(void)
{
  stack *s = stack_create();
  for (unsigned int i = 0; i < 10000; i++)
     stack_push(s, i);

  stack_free(&s);
  return 0;
}


  /*
  stack *v = stack_create();
  
  stack_push(v, 'c');
  stack_print(v);
  stack_push(v, 'e');
  stack_print(v);
  stack_push(v, 'l');
  stack_print(v);
  stack_push(v, 'i');
  stack_print(v);
  stack_push(v, 'a');

  stack_print(v);

  stack_free(&v);*/
