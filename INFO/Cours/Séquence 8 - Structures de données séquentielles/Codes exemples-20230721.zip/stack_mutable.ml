(* Une pile créée avec le module Stack n'est rien d'autre 
  qu'une liste OCaml (donc polymorphe) qui est rendue  mutable
  En interne, le type Stack.t est défini par
  type 'a t = {mutable c: 'a list; mutable len: int} *)

(* creation d'une file mutable, toujours vide initialement *)
let s = Stack.create ();;

(* Exception Empty: levée si on cherche à dépiler une pile vide *)
Stack.Empty;;

try
  Stack.pop s
with
  |Stack.Empty -> failwith "La pile est vide!"
;;

(* ajout d'elements en haut de la pile. 
Ici, on crée un pile de chaines de caractères  *)
Stack.push "toto" s;; 
Stack.push "titi" s;;
Stack.push "tata" s;;

(* affichage des elements *)
(* on cree une fonction d'affichage pour un element
 ici, comme on souhaite que chaque chaine soit suivie d'un espace
 lors de l'affichage on utilise l'opérateur de 
 concatenation de chaines de caracteres ^ *)
let print_element s = print_string (s^" ");;

(* utilisation de la fonction Stack.iter pour appliquer la fonction
   d'affichage successivement sur tous les éléments de la pile *)
let stack_print s =
  Stack.iter print_element s
;;
stack_print s;;

(* récupération de l'élément en haut de la pile*)
let top_value = Stack.top s;;

(* récupération et suppression de l'élément en haut de la pile *)
Stack.pop s;;
stack_print s;;
Stack.pop s;;
stack_print s;;
