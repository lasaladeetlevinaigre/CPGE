(* creation d'une file mutable *)
let q = Queue.create ();;

(* ajout d'elements en queue de file (enqueue). 
Ici, on crée un file de chaines de caractères  *)
(* Queue.push --> equivalent de enqueue *)
Queue.push "toto" q;; 
Queue.push "titi" q;;
Queue.push "tata" q;;

(* affichage des elements *)

(* on cree une fonction d'affichage pour un element
 ici, comme on souhaite que chaque chaine soit suivie d'un espace
 on utilise l'opérateur de concatenation de chaines ^ *)
let print_element s = print_string (s^" ");;

(* utilisation de la fonction Queue.iter pour appliquer la fonction
   d'affichage successivement sur tous les éléments de la file *)
let queue_print q =
  Queue.iter print_element q
;;
queue_print q;;

(* récupération de l'élément de tête *)

let peek_value = Queue.peek q;;

(* récupération et suppression de l'élément de tête*)
(* Queue.pop --> equivalent de dequeue *)
Queue.pop q;; 
queue_print q;;
Queue.pop q;;
queue_print q;;


(* Exception Empty: levée si on cherche à dépiler une pile vide *)
Queue.Empty;;

try
  Queue.pop q
with
  |Queue.Empty -> failwith "La file est vide!"
;;
