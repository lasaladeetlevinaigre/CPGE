(* création de listes/piles immuables: l'opérateur :: sert de push *)
let l1 = 2::4::[];;
let l2 = 5::l1;;

(* double "pop" sur l2 en combinant l'opérateur :: et la deconstruction de motif *)
let e1::e2::l3 = l2;;
l3;;

(* ni la liste l1, ni la liste l2 n'ont été modifiées*)
l1;;
l2;;

(* immuabilité lors de la concaténation *)
let l4 = l1@l2;;
l1;;
(* la premiere liste n'a pas été modifiée, 
        contrairement à ce qui se passe en C)
   Cela est lié au fait que, en interne, les  
   maillons de l1 ont été dupliqués pour garantir
   qu'aucun effet de bord ne peut avoir lieu *)
