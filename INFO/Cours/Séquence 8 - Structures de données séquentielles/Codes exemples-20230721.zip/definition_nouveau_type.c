#include <string.h>
#include <stdio.h>
#include <stdlib.h>

// définition d'un type groupe par énumération
// équivalent très appauvri du type somme OCaml
// en fait, derrière, ce sont des entiers (4 octets)
// MPII est un alias pour l'entier 0, MPSI1 un alias pour l'entier 1...etc
enum groupe {MPII, MPSI1, MPSI2};

// définition du type appelé "struct s_eleve", qui possède 4 champs
// équivalent du type produit enregistrement
struct s_eleve 
{
  char nom[256]; // 256 octets
  int age;       // 4 octets
  enum groupe classe; // 4 octets
  float notes[3];     // 3*4 octets
};

typedef struct s_eleve eleve;
// cela permet d'appeler notre type "eleve", au lieu de  "struct s_eleve",
//qui est plus long et lourd à écrire

int main(void)
{
  printf("Un objet de type enum groupe occupe %ld octets\n", sizeof(enum groupe));
  
  eleve e1 ;  // déclaration d'une variable de type "eleve"
              // dans le bloc d'activation du main, dans la pile

  // affectation des valeurs des différents champs
  strcpy(e1.nom, "Marque");
  e1.age = 18;
  e1.classe = MPII;
  e1.notes[0] = 19;
  e1.notes[1] = 17;
  e1.notes[2] = 19.5;

  // autre manière d'initialiser un objet de type eleve
  // (toujours stocké dans la pile)
  eleve e2 = {"Kitten", 18, MPII, {13.5, 18.5, 19.75} };

  // le point "." sert à accéder aux différents champs de l'objet,
  // comme en OCaml
  printf("%d\n", e2.age);
  printf("%f\n", e2.notes[1]);

  // allocation d'une variable de type eleve dans le tas
  eleve *pe = NULL; // l'objet sera stocké dans le tas, mais le pointeur,
                    // qui contiendra l'adresse de l'objet, est lui stocké 
                    // dans la pile, dans le bloc d'activation du main
  pe = malloc(sizeof(eleve));
  printf("Un objet de type eleve occupe %ld octets\n", sizeof(eleve));


  // acces aux champs à partir du POINTEUR avec ->
  pe->age = 19;
  strcpy(pe->nom, "Misplon");
  pe->classe = MPII;

  printf("%s\n", pe->nom);

  if (pe != NULL)
    free(pe);
  pe = NULL;
  
  return 0;
}
