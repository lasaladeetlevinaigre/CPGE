#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>

void print_tab(int n, short int *tab)
{
  for (int k = 0; k < n; k++)
    printf("%d", tab[k]);
  printf(" ");
}

unsigned int incr(int n, int N, short int *bits)
{

  assert(bits != NULL);

  print_tab(N, bits);
  
  int k = N-1;
  unsigned int nb_op = 0;
  
  while (k >= 0 && bits[k] == 1)
  {
    bits[k] = 0;
    k = k - 1;
    nb_op = nb_op + 2; // un test vrai bits[k] == 1
                       // + une affectation bits[k] = 0;
  }

  if (k >= 0)
  {
    bits[k] = 1;
    nb_op = nb_op + 2; // un test faux bits[k] == 1
                       // + une affectation bits[k] = 1;
  }

  printf("Nombre d'opérations: %d\n", nb_op);
  return nb_op; 
}



int main(int argc, char **argv)
{
  assert(argc == 2);
  int N = atoi(argv[1]);
  assert(N > 0);
  


  // allocation + mise à zéro
  short int *bits = calloc(N, sizeof(short int));

  // on verifie que l'allocation s'est bien passée
  assert(bits != NULL);

  int nb_num = pow(2, N)-1;
  
  for (int i = 0; i < nb_num; i++)
    incr(i, N, bits);
  
  
  free(bits);
  return 0;
}
